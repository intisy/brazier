/*
 *  Copyright 2024 Alexey Andreev.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package org.teavm.platform.plugin.wasmgc;

import org.teavm.ast.InvocationExpr;
import org.teavm.backend.wasm.generate.classes.WasmGCTypeMapper;
import org.teavm.backend.wasm.intrinsics.WasmGCInlineIntrinsic;
import org.teavm.backend.wasm.intrinsics.WasmGCInlineIntrinsicContext;
import org.teavm.backend.wasm.model.WasmArray;
import org.teavm.backend.wasm.model.WasmType;
import org.teavm.backend.wasm.model.instruction.WasmInstructionBuilder;
import org.teavm.model.ValueType;
import org.teavm.platform.metadata.ResourceArray;

public class WasmGCResourceArrayIntrinsic implements WasmGCInlineIntrinsic {
    private WasmGCTypeMapper typeMapper;

    public WasmGCResourceArrayIntrinsic(WasmGCTypeMapper typeMapper) {
        this.typeMapper = typeMapper;
    }

    @Override
    public void apply(InvocationExpr invocation, WasmGCInlineIntrinsicContext context,
            WasmInstructionBuilder builder) {
        switch (invocation.getMethod().getName()) {
            case "size":
                context.generate(builder, invocation.getArguments().get(0));
                builder.arrayLength();
                break;
            case "get":
                context.generate(builder, invocation.getArguments().get(0));
                context.generate(builder, invocation.getArguments().get(1));
                builder.arrayGet(getArrayType());
                break;
            default:
                throw new IllegalArgumentException();
        }
    }

    private WasmArray getArrayType() {
        var type = (WasmType.CompositeReference) typeMapper.mapType(ValueType.object(ResourceArray.class.getName()));
        return (WasmArray) type.composite;
    }
}
