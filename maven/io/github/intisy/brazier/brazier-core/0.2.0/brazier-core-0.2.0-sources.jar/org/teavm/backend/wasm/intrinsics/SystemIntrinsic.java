/*
 *  Copyright 2026 Alexey Andreev.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package org.teavm.backend.wasm.intrinsics;

import org.teavm.ast.InvocationExpr;
import org.teavm.backend.wasm.WasmFunctionTypes;
import org.teavm.backend.wasm.model.WasmFunction;
import org.teavm.backend.wasm.model.WasmModule;
import org.teavm.backend.wasm.model.WasmNumType;
import org.teavm.backend.wasm.model.WasmType;
import org.teavm.backend.wasm.model.instruction.WasmInstructionBuilder;

public class SystemIntrinsic implements WasmGCInlineIntrinsic {
    private WasmFunctionTypes functionTypes;
    private WasmModule module;
    private WasmFunction workerFunction;

    public SystemIntrinsic(WasmFunctionTypes functionTypes, WasmModule module) {
        this.functionTypes = functionTypes;
        this.module = module;
    }

    @Override
    public void apply(InvocationExpr invocation, WasmGCInlineIntrinsicContext context,
            WasmInstructionBuilder builder) {
        if (workerFunction == null) {
            workerFunction = new WasmFunction(functionTypes.of(WasmType.FLOAT64));
            workerFunction.setName("teavm@currentTimeMillis");
            workerFunction.setImportName("currentTimeMillis");
            workerFunction.setImportModule("teavmDate");
            module.functions.add(workerFunction);
        }
        builder.call(workerFunction).convert(WasmNumType.FLOAT64, WasmNumType.INT64, true);
    }
}
