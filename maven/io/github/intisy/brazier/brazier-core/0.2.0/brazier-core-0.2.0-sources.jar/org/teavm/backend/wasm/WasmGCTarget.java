/*
 *  Copyright 2024 Alexey Andreev.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package org.teavm.backend.wasm;

import java.io.IOException;
import java.io.StringWriter;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ServiceLoader;
import java.util.Set;
import java.util.function.Supplier;
import org.teavm.backend.c.analyze.InteropDependencyListener;
import org.teavm.backend.wasm.debug.CompositeDebugLines;
import org.teavm.backend.wasm.debug.DebugLines;
import org.teavm.backend.wasm.debug.ExternalDebugFile;
import org.teavm.backend.wasm.debug.GCDebugInfoBuilder;
import org.teavm.backend.wasm.debug.sourcemap.SourceMapBuilder;
import org.teavm.backend.wasm.dependencies.WasmGCDependencies;
import org.teavm.backend.wasm.generate.WasmGCDeclarationsGenerator;
import org.teavm.backend.wasm.generate.WasmGCInitializerRegistry;
import org.teavm.backend.wasm.generate.WasmGCNameProvider;
import org.teavm.backend.wasm.generate.WasmGeneratorUtil;
import org.teavm.backend.wasm.generate.classes.WasmGCClassInfoProvider;
import org.teavm.backend.wasm.generate.classes.WasmGCCustomTypeMapperFactory;
import org.teavm.backend.wasm.generate.classes.WasmGCTypeMapper;
import org.teavm.backend.wasm.generate.strings.WasmGCStringProvider;
import org.teavm.backend.wasm.intrinsics.WasmGCAsyncTypeMapperFactory;
import org.teavm.backend.wasm.intrinsics.WasmGCBodyIntrinsic;
import org.teavm.backend.wasm.intrinsics.WasmGCCodeGenContext;
import org.teavm.backend.wasm.intrinsics.WasmGCCodeGenContributor;
import org.teavm.backend.wasm.intrinsics.WasmGCCodeGenRegistry;
import org.teavm.backend.wasm.intrinsics.WasmGCInlineIntrinsic;
import org.teavm.backend.wasm.intrinsics.WasmGCIntrinsics;
import org.teavm.backend.wasm.intrinsics.WasmGCResourcesIntrinsic;
import org.teavm.backend.wasm.model.WasmCustomSection;
import org.teavm.backend.wasm.model.WasmFunction;
import org.teavm.backend.wasm.model.WasmGlobal;
import org.teavm.backend.wasm.model.WasmLocal;
import org.teavm.backend.wasm.model.WasmModule;
import org.teavm.backend.wasm.model.WasmTag;
import org.teavm.backend.wasm.model.WasmType;
import org.teavm.backend.wasm.optimization.WasmUsageCounter;
import org.teavm.backend.wasm.render.WasmBinaryRenderer;
import org.teavm.backend.wasm.render.WasmBinaryStatsCollector;
import org.teavm.backend.wasm.render.WasmBinaryVersion;
import org.teavm.backend.wasm.render.WasmBinaryWriter;
import org.teavm.backend.wasm.runtime.StringInternPool;
import org.teavm.backend.wasm.runtime.WasmGCResources;
import org.teavm.backend.wasm.transformation.BaseClassesTransformation;
import org.teavm.backend.wasm.transformation.ClassLoaderResourceTransformation;
import org.teavm.backend.wasm.transformation.EntryPointTransformation;
import org.teavm.backend.wasm.transformation.ReferenceQueueTransformation;
import org.teavm.backend.wasm.vtable.WasmGCVirtualTableProvider;
import org.teavm.classlib.ReflectionSupplier;
import org.teavm.common.JsonUtil;
import org.teavm.dependency.DependencyAnalyzer;
import org.teavm.dependency.DependencyInfo;
import org.teavm.dependency.DependencyListener;
import org.teavm.interop.Address;
import org.teavm.interop.Async;
import org.teavm.interop.Export;
import org.teavm.interop.Platforms;
import org.teavm.model.ClassHolderTransformer;
import org.teavm.model.ElementModifier;
import org.teavm.model.ListableClassHolderSource;
import org.teavm.model.ListableClassReaderSource;
import org.teavm.model.MethodReader;
import org.teavm.model.MethodReference;
import org.teavm.model.Program;
import org.teavm.model.lowlevel.Characteristics;
import org.teavm.model.lowlevel.LowLevelNullCheckFilter;
import org.teavm.model.optimization.InliningFilterFactory;
import org.teavm.model.transformation.BoundCheckInsertion;
import org.teavm.model.transformation.NullCheckInsertion;
import org.teavm.model.util.AsyncMethodFinder;
import org.teavm.model.util.VariableCategoryProvider;
import org.teavm.reflection.AnnotationGenerationHelper;
import org.teavm.reflection.ReflectionDependencyListener;
import org.teavm.runtime.heap.Heap;
import org.teavm.vm.BuildTarget;
import org.teavm.vm.TeaVMTarget;
import org.teavm.vm.TeaVMTargetController;
import org.teavm.vm.intrinsic.BaseIntrinsicContributorContext;
import org.teavm.vm.intrinsic.DefaultIntrinsicRegistry;
import org.teavm.vm.intrinsic.IntrinsicRegistry;
import org.teavm.vm.spi.TeaVMHostExtension;

public class WasmGCTarget implements TeaVMTarget, TeaVMWasmGCHost {
    private TeaVMTargetController controller;
    private NullCheckInsertion nullCheckInsertion;
    private BoundCheckInsertion boundCheckInsertion = new BoundCheckInsertion();
    private boolean strict;
    private boolean obfuscated;
    private boolean debugInfo;
    private boolean compactMode;
    private SourceMapBuilder sourceMapBuilder;
    private String sourceMapLocation;
    private WasmDebugInfoLocation debugLocation = WasmDebugInfoLocation.EXTERNAL;
    private WasmDebugInfoLevel debugLevel = WasmDebugInfoLevel.FULL;
    private int bufferHeapMinSize = 1024 * 1024 * 2;
    private boolean sharedBuffer;
    private List<WasmGCCustomTypeMapperFactory> customTypeMapperFactories = new ArrayList<>();
    private EntryPointTransformation entryPointTransformation = new EntryPointTransformation();
    private List<Supplier<Collection<MethodReference>>> additionalMethodsOnCallSites = new ArrayList<>();
    private List<WasmGCCodeGenContributor> intrinsicContributors = new ArrayList<>();

    private ReflectionDependencyListener reflection;

    private int dataSize;

    public WasmGCTarget() {
        customTypeMapperFactories.add(new WasmGCAsyncTypeMapperFactory());
    }

    public void setObfuscated(boolean obfuscated) {
        this.obfuscated = obfuscated;
    }

    public void setStrict(boolean strict) {
        this.strict = strict;
    }

    public void setDebugInfo(boolean debug) {
        this.debugInfo = debug;
    }

    public void setDebugInfoLevel(WasmDebugInfoLevel debugLevel) {
        this.debugLevel = debugLevel;
    }

    public void setDebugInfoLocation(WasmDebugInfoLocation debugLocation) {
        this.debugLocation = debugLocation;
    }

    public void setSourceMapBuilder(SourceMapBuilder sourceMapBuilder) {
        this.sourceMapBuilder = sourceMapBuilder;
    }

    public void setSourceMapLocation(String sourceMapLocation) {
        this.sourceMapLocation = sourceMapLocation;
    }

    public void setBufferHeapMinSize(int bufferHeapMinSize) {
        this.bufferHeapMinSize = bufferHeapMinSize;
    }

    public void setSharedBuffer(boolean sharedBuffer) {
        this.sharedBuffer = sharedBuffer;
    }

    public void setCompactMode(boolean compactMode) {
        this.compactMode = compactMode;
    }

    @Override
    public void addCustomTypeMapperFactory(WasmGCCustomTypeMapperFactory customTypeMapperFactory) {
        customTypeMapperFactories.add(customTypeMapperFactory);
    }

    @Override
    public void addMethodsOnCallSites(Supplier<Collection<MethodReference>> methodsOnCallSites) {
        additionalMethodsOnCallSites.add(methodsOnCallSites);
    }

    @Override
    public void setController(TeaVMTargetController controller) {
        var characteristics = new Characteristics(controller.getUnprocessedClassSource());
        nullCheckInsertion = new NullCheckInsertion(new LowLevelNullCheckFilter(characteristics));
        this.controller = controller;
        controller.addVirtualMethods(reflection::isVirtual);
    }

    @Override
    public void setEntryPoint(String entryPoint, String name) {
        entryPointTransformation.setEntryPoint(entryPoint);
        entryPointTransformation.setEntryPointName(name);
    }

    @Override
    public VariableCategoryProvider variableCategoryProvider() {
        return null;
    }

    @Override
    public List<DependencyListener> getDependencyListeners() {
        return List.of(new InteropDependencyListener());
    }

    @Override
    public List<ClassHolderTransformer> getTransformers() {
        return List.of(
                new BaseClassesTransformation(),
                new ClassLoaderResourceTransformation(),
                new ReferenceQueueTransformation(),
                entryPointTransformation
        );
    }

    @Override
    public void contributeDependencies(DependencyAnalyzer dependencyAnalyzer) {
        var deps = new WasmGCDependencies(dependencyAnalyzer);
        deps.contribute();
        deps.contributeStandardExports();

        var reflectionSuppliers = new ArrayList<ReflectionSupplier>();
        for (var supplier : ServiceLoader.load(ReflectionSupplier.class, dependencyAnalyzer.getClassLoader())) {
            reflectionSuppliers.add(supplier);
        }
        reflection = new ReflectionDependencyListener(reflectionSuppliers, new AnnotationGenerationHelper());
        dependencyAnalyzer.addDependencyListener(reflection);
    }

    @Override
    public List<TeaVMHostExtension> getHostExtensions() {
        return List.of(this);
    }

    @Override
    public void beforeInlining(Program program, MethodReader method) {
        if (strict) {
            nullCheckInsertion.transformProgram(program, method.getReference());
        }
    }

    @Override
    public void beforeOptimizations(Program program, MethodReader method) {
        if (strict) {
            boundCheckInsertion.transformProgram(program, method.getReference());
        }
    }

    @Override
    public void afterOptimizations(Program program, MethodReader method) {
    }

    @Override
    public String[] getPlatformTags() {
        return new String[] { Platforms.WEBASSEMBLY_GC };
    }

    @Override
    public boolean isAsyncSupported() {
        return true;
    }

    @Override
    public InliningFilterFactory getInliningFilter() {
        return ignore -> methodRef -> {
            var method = controller.getUnprocessedClassSource().getMethod(methodRef);
            if (method == null) {
                return true;
            }
            return method.getAnnotations().get(Async.class.getName()) == null;
        };
    }

    @Override
    public void contributeToCodeGen(WasmGCCodeGenContributor contributor) {
        intrinsicContributors.add(contributor);
    }

    @Override
    public void emit(ListableClassHolderSource classes, BuildTarget buildTarget, String outputName) throws IOException {
        var module = new WasmModule();
        module.memoryImportName = "memory";
        module.memoryImportModule = "env";
        controller.addVirtualMethods(reflection::isVirtual);
        addMethodsOnCallSites(reflection::getVirtualCallSites);
        var inlineIntrinsics = new DefaultIntrinsicRegistry<WasmGCInlineIntrinsic>(classes);
        var bodyIntrinsics = new DefaultIntrinsicRegistry<WasmGCBodyIntrinsic>(classes);
        var debugInfoBuilder = new GCDebugInfoBuilder();
        var methodsOnCallSites = new LinkedHashSet<MethodReference>();
        for (var provider : additionalMethodsOnCallSites) {
            methodsOnCallSites.addAll(provider.get());
        }
        var asyncMethodFinder = new AsyncMethodFinder(controller.getDependencyInfo().getCallGraph(),
                controller.getDependencyInfo());
        asyncMethodFinder.find(classes);
        var declarationsGenerator = new WasmGCDeclarationsGenerator(
                module,
                classes,
                controller.getUnprocessedClassSource(),
                controller.getResourceProvider(),
                controller.getClassLoader(),
                controller.getClassInitializerInfo(),
                controller.getDependencyInfo(),
                controller.getDiagnostics(),
                customTypeMapperFactories,
                controller::isVirtual,
                strict,
                controller.getEntryPoint(),
                methodsOnCallSites,
                inlineIntrinsics,
                bodyIntrinsics
        );
        declarationsGenerator.setAsyncMethodFinder(asyncMethodFinder);
        declarationsGenerator.setFriendlyToDebugger(controller.isFriendlyToDebugger());
        declarationsGenerator.setCompactMode(compactMode);
        var moduleGenerator = new WasmGCModuleGenerator(declarationsGenerator);
        var codeGenContext = createCodeGenContext(classes, declarationsGenerator,
                asyncMethodFinder.getAsyncFamilyMethods());
        var codeGenRegistry = createCodeGenRegistry(inlineIntrinsics, bodyIntrinsics);
        WasmGCIntrinsics.apply(reflection, codeGenContext, inlineIntrinsics, bodyIntrinsics);
        for (var contributor : intrinsicContributors) {
            contributor.contribute(codeGenContext, codeGenRegistry);
        }
        var resourceGenerator = new WasmGCResourcesIntrinsic(controller.getProperties(), codeGenContext,
                controller.extensionEnvironment());
        inlineIntrinsics.registerIntrinsic(WasmGCResources.class, resourceGenerator);

        var internMethod = controller.getDependencyInfo().getMethod(new MethodReference(String.class,
                "intern", String.class));
        if (internMethod != null && internMethod.isUsed()) {
            var removeStringEntryFunction = moduleGenerator.generateReportGarbageCollectedStringFunction();
            removeStringEntryFunction.setExportName("teavm.reportGarbageCollectedString");
        }

        var exceptionMessageRef = new MethodReference(Throwable.class, "getMessage", String.class);
        if (controller.getDependencyInfo().getMethod(exceptionMessageRef) != null) {
            var exceptionMessageFunction = declarationsGenerator.functions().forInstanceMethod(exceptionMessageRef);
            exceptionMessageFunction.setExportName("teavm.exceptionMessage");
        }

        var refQueueSupplyRef = new MethodReference(ReferenceQueue.class, "supply", Reference.class, void.class);
        if (controller.getDependencyInfo().getMethod(refQueueSupplyRef) != null) {
            var refQueueSupplyFunction = declarationsGenerator.functions().forInstanceMethod(refQueueSupplyRef);
            refQueueSupplyFunction.setExportName("teavm.reportGarbageCollectedValue");
        }

        var buffersHeap = needsBuffersHeap(controller.getDependencyInfo());
        if (buffersHeap) {
            declarationsGenerator.functions().forStaticMethod(new MethodReference(Heap.class, "init",
                    Address.class, int.class, int.class, void.class));
        }
        for (var clsName : classes.getClassNames()) {
            var cls = classes.get(clsName);
            for (var method : cls.getMethods()) {
                if (method.hasModifier(ElementModifier.STATIC)
                        && method.getProgram() != null
                        && method.getAnnotations().get(Export.class.getName()) != null) {
                    declarationsGenerator.functions().forStaticMethod(method.getReference());
                }
            }
        }
        moduleGenerator.generate();
        resourceGenerator.writeModule(module);
        generateExceptionExports(declarationsGenerator);
        adjustModuleMemory(module, moduleGenerator, buffersHeap);

        emitWasmFile(module, buildTarget, outputName, debugInfoBuilder);
    }

    private void generateExceptionExports(WasmGCDeclarationsGenerator declarationsGenerator) {
        var nativeExceptionField = declarationsGenerator.classInfoProvider().getThrowableNativeOffset();
        if (nativeExceptionField < 0) {
            return;
        }

        var throwableType = declarationsGenerator.classInfoProvider().getClassInfo("java.lang.Throwable")
                .getStructure();

        var getFunction = new WasmFunction(declarationsGenerator.functionTypes.of(WasmType.EXTERN,
                throwableType.getReference()));
        getFunction.setName("teavm.getJsException");
        getFunction.setExportName("teavm.getJsException");
        var getParam = new WasmLocal(throwableType.getReference(), "javaException");
        getFunction.add(getParam);
        getFunction.getBody().builder()
                .getLocal(getParam)
                .structGet(throwableType, nativeExceptionField);
        declarationsGenerator.module.functions.add(getFunction);

        var setFunction = new WasmFunction(declarationsGenerator.functionTypes.of(null, throwableType.getReference(),
                WasmType.EXTERN));
        setFunction.setName("teavm.setJsException");
        setFunction.setExportName("teavm.setJsException");
        var setParam = new WasmLocal(throwableType.getReference(), "javaException");
        var setValue = new WasmLocal(WasmType.EXTERN, "jsException");
        setFunction.add(setParam);
        setFunction.add(setValue);
        setFunction.getBody().builder()
                .getLocal(setParam)
                .getLocal(setValue)
                .structSet(throwableType, nativeExceptionField);
        declarationsGenerator.module.functions.add(setFunction);
    }

    private WasmGCCodeGenContext createCodeGenContext(
            ListableClassReaderSource classes,
            WasmGCDeclarationsGenerator generator,
            Set<MethodReference> asyncSplitMethods
    ) {
        class ContextImpl extends BaseIntrinsicContributorContext implements WasmGCCodeGenContext {
            ContextImpl() {
                super(controller, generator.hierarchy, classes, asyncSplitMethods);
            }

            @Override
            public WasmModule module() {
                return generator.module;
            }

            @Override
            public WasmFunctionTypes functionTypes() {
                return generator.functionTypes;
            }

            @Override
            public BaseWasmFunctionRepository functions() {
                return generator.functions();
            }

            @Override
            public WasmGCNameProvider names() {
                return generator.names();
            }

            @Override
            public WasmGCStringProvider strings() {
                return generator.strings();
            }

            @Override
            public WasmGCTypeMapper typeMapper() {
                return generator.typeMapper();
            }

            @Override
            public WasmTag exceptionTag() {
                return generator.exceptionTag();
            }

            @Override
            public String entryPoint() {
                return controller.getEntryPoint();
            }

            @Override
            public WasmGCClassInfoProvider classInfoProvider() {
                return generator.classInfoProvider();
            }

            @Override
            public WasmGCVirtualTableProvider virtualTables() {
                return generator.virtualTables;
            }

            @Override
            public WasmGCInitializerRegistry initializerRegistry() {
                return initializerRegistry;
            }

            private WasmGCInitializerRegistry initializerRegistry = generator::addToInitializer;
        }
        return new ContextImpl();
    }

    private WasmGCCodeGenRegistry createCodeGenRegistry(
            IntrinsicRegistry<WasmGCInlineIntrinsic> callSiteIntrinsics,
            IntrinsicRegistry<WasmGCBodyIntrinsic> bodyIntrinsics) {
        return new WasmGCCodeGenRegistry() {
            @Override
            public IntrinsicRegistry<WasmGCInlineIntrinsic> inlineIntrinsics() {
                return callSiteIntrinsics;
            }

            @Override
            public IntrinsicRegistry<WasmGCBodyIntrinsic> bodyIntrinsics() {
                return bodyIntrinsics;
            }
        };
    }

    private void adjustModuleMemory(WasmModule module, WasmGCModuleGenerator moduleGenerator, boolean buffersHeap) {
        var memorySize = 0;
        for (var segment : module.getSegments()) {
            memorySize = Math.max(memorySize, segment.getOffset() + segment.getLength());
        }

        var heapOffset = new WasmGlobal("heapOffset", WasmType.INT32);
        heapOffset.setImmutable(true);
        heapOffset.setImportModule("teavmMemory");
        heapOffset.setImportName("heapOffset");
        module.globals.add(heapOffset);

        var maxSize = new WasmGlobal("maxSize", WasmType.INT32);
        maxSize.setImmutable(true);
        maxSize.setImportModule("teavmMemory");
        maxSize.setImportName("maxSize");
        module.globals.add(maxSize);

        dataSize = memorySize;
        if (buffersHeap) {
            memorySize = ((memorySize - 1) / 256 + 1) * 256;
            moduleGenerator.initBuffersHeap(heapOffset, bufferHeapMinSize, maxSize);
            memorySize += bufferHeapMinSize;
        }

        var pages = (memorySize - 1) / WasmGeneratorUtil.PAGE_SIZE + 1;
        module.setMinMemorySize(pages);
        module.setMaxMemorySize(32768);
        module.sharedMemory = sharedBuffer;
    }

    private static boolean needsBuffersHeap(DependencyInfo dependencyInfo) {
        return dependencyInfo.getReachableMethods().stream()
                .anyMatch(m -> m.getClassName().equals(Heap.class.getName())
                        && !m.getName().equals("init"));
    }

    private void emitWasmFile(WasmModule module, BuildTarget buildTarget, String outputName,
            GCDebugInfoBuilder debugInfoBuilder) throws IOException {
        var binaryWriter = new WasmBinaryWriter();
        DebugLines debugLines = null;
        if (debugInfo) {
            if (sourceMapBuilder != null) {
                debugLines = new CompositeDebugLines(debugInfoBuilder.lines(), sourceMapBuilder);
            } else {
                debugLines = debugInfoBuilder.lines();
            }
        } else if (sourceMapBuilder != null) {
            debugLines = sourceMapBuilder;
        }
        if (!outputName.endsWith(".wasm")) {
            outputName += ".wasm";
        }
        if (sourceMapBuilder != null && sourceMapLocation != null) {
            var sourceMapBinding = new WasmBinaryWriter();
            sourceMapBinding.writeAsciiString(sourceMapLocation);
            var sourceMapSection = new WasmCustomSection("sourceMappingURL", sourceMapBinding.getData());
            module.add(sourceMapSection);
        }
        var binaryRenderer = new WasmBinaryRenderer(binaryWriter, WasmBinaryVersion.V_0x1, obfuscated,
                null, null, debugLines, null, WasmBinaryStatsCollector.EMPTY);
        optimizeIndexes(module);
        module.prepareForRendering();
        binaryRenderer.render(module, customSections(debugInfoBuilder, module));
        var data = binaryWriter.getData();
        try (var output = buildTarget.createResource(outputName)) {
            output.write(data);
        }
        if (debugLocation == WasmDebugInfoLocation.EXTERNAL && debugInfo) {
            var debugInfoData = ExternalDebugFile.write(debugInfoBuilder.build());
            if (debugInfoData != null) {
                try (var output = buildTarget.createResource(outputName + ".teadbg")) {
                    output.write(debugInfoData);
                }
            }
        }
    }

    private Supplier<Collection<? extends WasmCustomSection>> customSections(GCDebugInfoBuilder debugInfoBuilder,
            WasmModule module) {
        return () -> {
            var list = new ArrayList<WasmCustomSection>();
            if (debugLocation == WasmDebugInfoLocation.EMBEDDED && debugInfo) {
                list.addAll(debugInfoBuilder.build());
            }
            var reqs = writeMemoryRequirements(module);
            list.add(new WasmCustomSection("teavm.memoryRequirements", reqs));
            list.add(new WasmCustomSection("teavm.imports", writeImportedModules(module)));
            return list;
        };
    }

    private byte[] writeMemoryRequirements(WasmModule module) {
        var data = "{\"min\":" + module.getMinMemorySize() + ", \"dataSize\":" + dataSize
                + ", \"shared\": " + sharedBuffer + "}";
        return data.getBytes(StandardCharsets.UTF_8);
    }

    private byte[] writeImportedModules(WasmModule module) {
        var writer = new StringWriter();
        try {
            writer.write("[");
            var first = true;
            for (var global : module.globals) {
                if (global.getImportModule() != null && global.getImportName() != null) {
                    if (!first) {
                        writer.write(",");
                    }
                    first = false;
                    writer.write("{\"module\":\"");
                    JsonUtil.writeEscapedString(writer, global.getImportModule());
                    writer.write("\",\"name\":\"");
                    JsonUtil.writeEscapedString(writer, global.getImportName());
                    writer.write("\"}");
                }
            }
            writer.write("]");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return writer.toString().getBytes(StandardCharsets.UTF_8);
    }

    private void optimizeIndexes(WasmModule module) {
        var usageCounter = new WasmUsageCounter();
        usageCounter.applyToModule(module);
        module.functions.sort(Comparator.comparingInt(f -> -usageCounter.usages(f)));
        module.globals.sort(Comparator.comparingInt(g -> -usageCounter.usages(g)));
        module.types.sort(Comparator.comparingInt(t -> -usageCounter.usages(t)));
    }

    @Override
    public boolean needsSystemArrayCopyOptimization() {
        return false;
    }

    @Override
    public boolean filterClassInitializer(String initializer) {
        if (initializer.equals(StringInternPool.class.getName())) {
            return false;
        }
        return true;
    }
}
