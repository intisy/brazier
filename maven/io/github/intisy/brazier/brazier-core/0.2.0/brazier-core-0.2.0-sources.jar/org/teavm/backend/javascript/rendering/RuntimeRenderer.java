/*
 *  Copyright 2018 Alexey Andreev.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
// Modified 2026 by the Brazier project (https://github.com/intisy/brazier).
package org.teavm.backend.javascript.rendering;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.mozilla.javascript.CompilerEnvirons;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.AstRoot;
import org.teavm.backend.javascript.codegen.SourceWriter;
import org.teavm.backend.javascript.codegen.SourceWriterSink;
import org.teavm.backend.javascript.templating.AstRemoval;
import org.teavm.backend.javascript.templating.RemovablePartsFinder;
import org.teavm.backend.javascript.templating.TemplatingAstTransformer;
import org.teavm.backend.javascript.templating.TemplatingAstWriter;
import org.teavm.model.ClassReaderSource;
import org.teavm.model.analysis.ClassInitializerInfo;
import org.teavm.vm.RenderingException;

public class RuntimeRenderer {
    /**
     * The top-level runtime declarations that hold state belonging to ONE module, which a shared
     * runtime therefore keeps to itself and every consumer renders for itself.
     *
     * @implNote Sharing any of these silently corrupts state. The string pool and the package table
     *     are each a setter every module calls with its own data, plus the reader that indexes it;
     *     {@code $rt_proxyMethods} is keyed by a counter that restarts in every module, so two
     *     modules mint the same key for different methods. Every other runtime declaration is either
     *     pure, or state that is deliberately shared (the identity-hash seed, the class registry,
     *     the intern table, the current thread, the metadata symbols).
     */
    public static final Set<String> PER_MODULE_NAMES = Set.of(
            "$rt_stringPool_instance",
            "$rt_stringPool",
            "$rt_s",
            "$rt_packageData",
            "$rt_packages",
            "$rt_metadata",
            "$rt_proxyMethods");

    private final List<AstRoot> runtimeAstParts = new ArrayList<>();
    private final List<AstRoot> epilogueAstParts = new ArrayList<>();
    private final RemovablePartsFinder removablePartsFinder = new RemovablePartsFinder();
    private final ClassReaderSource classSource;
    private final SourceWriter writer;
    private final ClassInitializerInfo classInitializerInfo;
    private final Set<String> topLevelNames = new HashSet<>();

    public RuntimeRenderer(ClassReaderSource classSource, SourceWriter writer,
            ClassInitializerInfo classInitializerInfo) {
        this.classSource = classSource;
        this.writer = writer;
        this.classInitializerInfo = classInitializerInfo;
    }

    public void prepareAstParts(boolean threadLibraryUsed) {
        runtimeAstParts.add(prepareAstPart("runtime.js"));
        runtimeAstParts.add(prepareAstPart("primitive.js"));
        runtimeAstParts.add(prepareAstPart("numeric.js"));
        runtimeAstParts.add(prepareAstPart("long.js"));
        runtimeAstParts.add(prepareAstPart("array.js"));
        runtimeAstParts.add(prepareAstPart("string.js"));
        runtimeAstParts.add(prepareAstPart("reflection.js"));
        runtimeAstParts.add(prepareAstPart("exception.js"));
        runtimeAstParts.add(prepareAstPart("check.js"));
        runtimeAstParts.add(prepareAstPart("console.js"));
        runtimeAstParts.add(prepareAstPart("metadata.js"));
        runtimeAstParts.add(prepareAstPart(threadLibraryUsed ? "thread.js" : "simpleThread.js"));
        epilogueAstParts.add(prepareAstPart("types.js"));
    }

    /**
     * {@return every name the hand-written runtime parts declare at the top level}
     *
     * @implNote A shared runtime exports these alongside the class declarations, because a consumer
     *     that emits none of the runtime parts still calls into them.
     */
    public Set<String> getTopLevelNames() {
        return Collections.unmodifiableSet(topLevelNames);
    }

    public void renderRuntime() {
        for (var ast : runtimeAstParts) {
            renderRuntimePart(ast);
        }
    }

    public void renderEpilogue() {
        for (var ast : epilogueAstParts) {
            renderRuntimePart(ast);
        }
    }

    private AstRoot prepareAstPart(String name) {
        var ast = parseRuntime(name);
        ast.visit(new StringConstantElimination());
        new TemplatingAstTransformer(classSource).visit(ast);
        removablePartsFinder.visit(ast);
        topLevelNames.addAll(ast.getSymbolTable().keySet());
        return ast;
    }

    private void renderRuntimePart(AstRoot ast)  {
        var astWriter = new TemplatingAstWriter(writer, classInitializerInfo, true);
        for (var name : topLevelNames) {
            astWriter.declareNameEmitter(name, (w, prec) -> w.appendFunction(name));
        }
        astWriter.print(ast);
    }

    private AstRoot parseRuntime(String name) {
        CompilerEnvirons env = new CompilerEnvirons();
        env.setRecoverFromErrors(true);
        env.setLanguageVersion(Context.VERSION_1_8);
        JSParser factory = new JSParser(env);

        ClassLoader loader = RuntimeRenderer.class.getClassLoader();
        try (InputStream input = loader.getResourceAsStream("org/teavm/backend/javascript/" + name);
                Reader reader = new InputStreamReader(input, StandardCharsets.UTF_8)) {
            return factory.parse(reader, null, 0);
        } catch (IOException e) {
            throw new RenderingException(e);
        }
    }

    public final SourceWriterSink sink = new SourceWriterSink() {
        @Override
        public SourceWriterSink appendFunction(String name) {
            removablePartsFinder.markUsedDeclaration(name);
            return this;
        }
    };

    public void removeUnusedParts() {
        removeParts(removablePartsFinder.getAllRemovableParts());
    }

    /**
     * Drops every runtime declaration outside {@link #PER_MODULE_NAMES}, leaving a consumer with
     * only the state it must own and importing the rest from the shared runtime.
     */
    public void retainPerModuleParts() {
        removeParts(removablePartsFinder.getPartsExcept(PER_MODULE_NAMES));
    }

    private void removeParts(Set<AstNode> parts) {
        var removal = new AstRemoval(parts);
        for (var part : runtimeAstParts) {
            removal.visit(part);
        }
        for (var part : epilogueAstParts) {
            removal.visit(part);
        }
    }
}
