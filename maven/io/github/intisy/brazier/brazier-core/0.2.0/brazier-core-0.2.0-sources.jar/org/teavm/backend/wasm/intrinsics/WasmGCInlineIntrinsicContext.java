/*
 *  Copyright 2026 Alexey Andreev.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package org.teavm.backend.wasm.intrinsics;

import org.teavm.ast.Expr;
import org.teavm.backend.wasm.generate.TemporaryVariablePool;
import org.teavm.backend.wasm.generate.ValueCache;
import org.teavm.backend.wasm.model.instruction.WasmInstructionBuilder;
import org.teavm.backend.wasm.types.PreciseTypeInference;
import org.teavm.model.MethodReference;

public interface WasmGCInlineIntrinsicContext {
    void generate(WasmInstructionBuilder builder, Expr expr);

    PreciseTypeInference types();

    TemporaryVariablePool tempVars();

    ValueCache valueCache();

    boolean isAsync();

    boolean isAsyncMethod(MethodReference method);

    MethodReference currentMethod();
}
