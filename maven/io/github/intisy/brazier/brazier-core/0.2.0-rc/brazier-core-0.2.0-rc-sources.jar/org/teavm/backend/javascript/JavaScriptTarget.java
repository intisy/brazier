/*
 *  Copyright 2016 Alexey Andreev.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
// Modified 2026 by the Brazier project (https://github.com/intisy/brazier).
package org.teavm.backend.javascript;

import com.carrotsearch.hppc.ObjectIntHashMap;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.ServiceLoader;
import java.util.Set;
import java.util.function.Function;
import org.teavm.ast.ControlFlowEntry;
import org.teavm.backend.javascript.codegen.AliasProvider;
import org.teavm.backend.javascript.codegen.DefaultAliasProvider;
import org.teavm.backend.javascript.codegen.DefaultNamingStrategy;
import org.teavm.backend.javascript.codegen.DeterministicAliasProvider;
import org.teavm.backend.javascript.codegen.MinifyingAliasProvider;
import org.teavm.backend.javascript.codegen.OutputSourceWriter;
import org.teavm.backend.javascript.codegen.OutputSourceWriterBuilder;
import org.teavm.backend.javascript.codegen.RememberedSource;
import org.teavm.backend.javascript.codegen.RememberingSourceWriter;
import org.teavm.backend.javascript.codegen.SourceWriter;
import org.teavm.backend.javascript.intrinsics.ref.ReferenceQueueGenerator;
import org.teavm.backend.javascript.intrinsics.ref.ReferenceQueueTransformer;
import org.teavm.backend.javascript.intrinsics.ref.WeakReferenceDependencyListener;
import org.teavm.backend.javascript.intrinsics.ref.WeakReferenceGenerator;
import org.teavm.backend.javascript.intrinsics.ref.WeakReferenceTransformer;
import org.teavm.backend.javascript.intrinsics.reflection.ReflectionIntrinsics;
import org.teavm.backend.javascript.rendering.NameFrequencyEstimator;
import org.teavm.backend.javascript.rendering.Renderer;
import org.teavm.backend.javascript.rendering.RenderingContext;
import org.teavm.backend.javascript.rendering.RenderingUtil;
import org.teavm.backend.javascript.rendering.RuntimeRenderer;
import org.teavm.backend.javascript.sharedruntime.DeclarationCollector;
import org.teavm.backend.javascript.sharedruntime.SharedRuntimeManifest;
import org.teavm.backend.javascript.spi.GeneratedBy;
import org.teavm.backend.javascript.spi.Generator;
import org.teavm.backend.javascript.spi.InjectedBy;
import org.teavm.backend.javascript.spi.Injector;
import org.teavm.backend.javascript.spi.MethodContributor;
import org.teavm.backend.javascript.spi.MethodContributorContext;
import org.teavm.backend.javascript.templating.JavaScriptTemplateFactory;
import org.teavm.cache.EmptyMethodNodeCache;
import org.teavm.cache.MethodNodeCache;
import org.teavm.classlib.ReflectionSupplier;
import org.teavm.debugging.information.DebugInformationEmitter;
import org.teavm.debugging.information.DummyDebugInformationEmitter;
import org.teavm.debugging.information.SourceLocation;
import org.teavm.dependency.AbstractDependencyListener;
import org.teavm.dependency.DependencyAgent;
import org.teavm.dependency.DependencyAnalyzer;
import org.teavm.dependency.DependencyListener;
import org.teavm.dependency.DependencyType;
import org.teavm.dependency.MethodDependency;
import org.teavm.interop.PlatformMarker;
import org.teavm.interop.Platforms;
import org.teavm.model.BasicBlock;
import org.teavm.model.CallLocation;
import org.teavm.model.ClassHolderTransformer;
import org.teavm.model.ClassReaderSource;
import org.teavm.model.ElementModifier;
import org.teavm.model.FieldReference;
import org.teavm.model.ListableClassHolderSource;
import org.teavm.model.MethodHolder;
import org.teavm.model.MethodReader;
import org.teavm.model.MethodReference;
import org.teavm.model.Program;
import org.teavm.model.TextLocation;
import org.teavm.model.ValueType;
import org.teavm.model.Variable;
import org.teavm.model.instructions.ConstructInstruction;
import org.teavm.model.instructions.InvocationType;
import org.teavm.model.instructions.InvokeInstruction;
import org.teavm.model.instructions.RaiseInstruction;
import org.teavm.model.instructions.StringConstantInstruction;
import org.teavm.model.transformation.BoundCheckInsertion;
import org.teavm.model.transformation.NullCheckFilter;
import org.teavm.model.transformation.NullCheckInsertion;
import org.teavm.model.util.DefaultVariableCategoryProvider;
import org.teavm.model.util.VariableCategoryProvider;
import org.teavm.reflection.AnnotationGenerationHelper;
import org.teavm.reflection.ReflectionDependencyListener;
import org.teavm.runtime.reflect.ClassInfo;
import org.teavm.vm.BuildTarget;
import org.teavm.vm.RenderingException;
import org.teavm.vm.TeaVM;
import org.teavm.vm.TeaVMOptimizationLevel;
import org.teavm.vm.TeaVMTarget;
import org.teavm.vm.TeaVMTargetController;
import org.teavm.vm.spi.RendererListener;
import org.teavm.vm.spi.TeaVMHostExtension;

public class JavaScriptTarget implements TeaVMTarget, TeaVMJavaScriptHost {
    private static final NumberFormat STATS_NUM_FORMAT = new DecimalFormat("#,##0");
    private static final NumberFormat STATS_PERCENT_FORMAT = new DecimalFormat("0.000 %");
    private static final MethodReference CURRENT_THREAD = new MethodReference(Thread.class,
            "currentThread", Thread.class);
    private static final String MAIN_EXPORT_ALIAS = "$rt_export_main";

    private TeaVMTargetController controller;
    private boolean obfuscated = true;
    private boolean stackTraceIncluded;
    private final Map<MethodReference, Generator> methodGenerators = new HashMap<>();
    private final Map<MethodReference, Injector> methodInjectors = new HashMap<>();
    private final List<Function<ProviderContext, Generator>> generatorProviders = new ArrayList<>();
    private final List<Function<ProviderContext, Injector>> injectorProviders = new ArrayList<>();
    private final List<RendererListener> rendererListeners = new ArrayList<>();
    private DebugInformationEmitter debugEmitter;
    private MethodNodeCache astCache = EmptyMethodNodeCache.INSTANCE;
    private final Set<MethodReference> asyncMethods = new HashSet<>();
    private List<MethodContributor> customVirtualMethods = new ArrayList<>();
    private List<MethodContributor> forcedFunctionMethods = new ArrayList<>();
    private boolean strict;
    private BoundCheckInsertion boundCheckInsertion = new BoundCheckInsertion();
    private NullCheckInsertion nullCheckInsertion = new NullCheckInsertion(NullCheckFilter.EMPTY);
    private final Map<String, String> importedModules = new LinkedHashMap<>();
    private JavaScriptTemplateFactory templateFactory;
    private JSModuleType moduleType = JSModuleType.UMD;
    private List<ExportedDeclaration> exports = new ArrayList<>();
    private int maxTopLevelNames = 80_000;
    private boolean deterministicNames;
    private static final String BOTH_MODES =
            "A module cannot both emit and import a shared runtime.";
    private final Set<String> sharedRuntimeClasses = new LinkedHashSet<>();
    private final Set<String> emittedTopLevelAliases = new LinkedHashSet<>();
    private final Set<String> emittedClassNames = new LinkedHashSet<>();
    private final Set<String> importedAliases = new LinkedHashSet<>();
    private SharedRuntimeManifest importedRuntime;
    private String importedRuntimeModule;

    private ReflectionDependencyListener reflection;

    @Override
    public List<ClassHolderTransformer> getTransformers() {
        return List.of(
                new WeakReferenceTransformer(),
                new ReferenceQueueTransformer()
        );
    }

    @Override
    public List<DependencyListener> getDependencyListeners() {
        return Collections.emptyList();
    }

    @Override
    public void setController(TeaVMTargetController controller) {
        this.controller = controller;

        templateFactory = new JavaScriptTemplateFactory(controller.getClassLoader(),
                controller.getDependencyInfo().getClassSource());

        var weakRefGenerator = new WeakReferenceGenerator(templateFactory);
        methodGenerators.put(new MethodReference(WeakReference.class, "<init>", Object.class,
                ReferenceQueue.class, void.class), weakRefGenerator);
        methodGenerators.put(new MethodReference(WeakReference.class, "get", Object.class), weakRefGenerator);
        methodGenerators.put(new MethodReference(WeakReference.class, "clear", void.class), weakRefGenerator);

        var refQueueGenerator = new ReferenceQueueGenerator();
        methodGenerators.put(new MethodReference(ReferenceQueue.class, "<init>", void.class), refQueueGenerator);
        methodGenerators.put(new MethodReference(ReferenceQueue.class, "poll", Reference.class), refQueueGenerator);
    }

    @Override
    public void add(RendererListener listener) {
        rendererListeners.add(listener);
    }

    @Override
    public void add(MethodReference methodRef, Generator generator) {
        methodGenerators.put(methodRef, generator);
    }

    @Override
    public void add(MethodReference methodRef, Injector injector) {
        methodInjectors.put(methodRef, injector);
    }

    @Override
    public void addGeneratorProvider(Function<ProviderContext, Generator> provider) {
        generatorProviders.add(provider);
    }

    @Override
    public void addInjectorProvider(Function<ProviderContext, Injector> provider) {
        injectorProviders.add(provider);
    }

    /**
     * Specifies whether this TeaVM instance uses obfuscation when generating the JavaScript code.
     *
     * @param obfuscated whether TeaVM should obfuscate code.
     */
    public void setObfuscated(boolean obfuscated) {
        this.obfuscated = obfuscated;
    }

    public MethodNodeCache getAstCache() {
        return astCache;
    }

    public void setAstCache(MethodNodeCache methodAstCache) {
        this.astCache = methodAstCache;
    }

    public DebugInformationEmitter getDebugEmitter() {
        return debugEmitter;
    }

    public void setDebugEmitter(DebugInformationEmitter debugEmitter) {
        this.debugEmitter = debugEmitter;
    }

    public void setStrict(boolean strict) {
        this.strict = strict;
    }

    public void setModuleType(JSModuleType moduleType) {
        this.moduleType = moduleType;
    }

    @Override
    public VariableCategoryProvider variableCategoryProvider() {
        return new DefaultVariableCategoryProvider();
    }

    public void setStackTraceIncluded(boolean stackTraceIncluded) {
        this.stackTraceIncluded = stackTraceIncluded;
    }

    public void setMaxTopLevelNames(int maxTopLevelNames) {
        this.maxTopLevelNames = maxTopLevelNames;
    }

    /**
     * Names every member from its identity alone, so independently compiled programs agree on the
     * name of a member they both reach. Takes precedence over {@link #setObfuscated}, whose short
     * names are minted in encounter order and cannot be shared.
     *
     * @param deterministicNames whether to use deterministic naming
     */
    public void setDeterministicNames(boolean deterministicNames) {
        this.deterministicNames = deterministicNames;
    }

    /**
     * Emits these classes whole, keeps every runtime part, and exports every top-level declaration,
     * so other programs can import from this module instead of emitting the same classes themselves.
     *
     * @param classNames the classes the runtime is to contain; empty leaves the target in its
     *     ordinary mode
     */
    public void setSharedRuntimeClasses(Collection<String> classNames) {
        if (importedRuntime != null && !classNames.isEmpty()) {
            throw new IllegalStateException(BOTH_MODES);
        }
        sharedRuntimeClasses.clear();
        sharedRuntimeClasses.addAll(classNames);
    }

    /**
     * Imports every class this manifest names instead of emitting it.
     *
     * @param manifest what the runtime contains
     * @param moduleSpecifier the module to import from, written into the generated import verbatim
     */
    public void setImportedRuntime(SharedRuntimeManifest manifest, String moduleSpecifier) {
        if (!sharedRuntimeClasses.isEmpty()) {
            throw new IllegalStateException(BOTH_MODES);
        }
        importedRuntime = manifest;
        importedRuntimeModule = moduleSpecifier;
    }

    /** {@return the classes this module emits as a shared runtime, empty when it emits none} */
    public Set<String> getSharedRuntimeClasses() {
        return Collections.unmodifiableSet(sharedRuntimeClasses);
    }

    /** {@return every top-level alias this module declared, which is what its manifest records} */
    public Set<String> getEmittedTopLevelAliases() {
        return Collections.unmodifiableSet(emittedTopLevelAliases);
    }

    /**
     * {@return every class this module emitted}
     *
     * @implNote The manifest records these rather than the classes the build was ASKED to preserve.
     *     Preserving a class pulls in whatever it reaches, so a runtime emits far more than it was
     *     given, and a consumer told only about the requested ones would import an alias of an
     *     unlisted class while emitting that class itself, declaring the same name twice.
     */
    public Set<String> getEmittedClassNames() {
        return Collections.unmodifiableSet(emittedClassNames);
    }

    /**
     * Refuses a shared-runtime build that would optimise against a world its consumers are not
     * part of.
     *
     * @param level the level this build would run at
     * @implNote Above SIMPLE the compiler devirtualises against the closed world, and that decides
     *     whether a method gets a prototype slot at all. A consumer subclassing a runtime class
     *     would then have nothing to override, and nothing would fail to link. See TeaVM's guarded
     *     call to devirtualize.
     */
    public void checkSharedRuntimeOptimizationLevel(TeaVMOptimizationLevel level) {
        if (!sharedRuntimeClasses.isEmpty() && level != TeaVMOptimizationLevel.SIMPLE) {
            throw new IllegalStateException("A shared runtime must be compiled at SIMPLE, not " + level
                    + ": a higher level devirtualises against a closed world that its consumers are "
                    + "not part of.");
        }
    }

    @Override
    public List<TeaVMHostExtension> getHostExtensions() {
        return Collections.singletonList(this);
    }

    @Override
    public void contributeDependencies(DependencyAnalyzer dependencyAnalyzer) {
        var reflectionSuppliers = new ArrayList<ReflectionSupplier>();
        for (var supplier : ServiceLoader.load(ReflectionSupplier.class, dependencyAnalyzer.getClassLoader())) {
            reflectionSuppliers.add(supplier);
        }
        reflection = new ReflectionDependencyListener(reflectionSuppliers, new AnnotationGenerationHelper());
        addVirtualMethods((ctx, method) -> reflection.isVirtual(method));

        MethodDependency dep;

        DependencyType stringType = dependencyAnalyzer.getClassType("java.lang.String");

        dependencyAnalyzer.linkMethod(new MethodReference(Class.class, "create", ClassInfo.class, Class.class)).use();

        dep = dependencyAnalyzer.linkMethod(new MethodReference(String.class, "<init>", Object.class, void.class));
        dep.getVariable(0).propagate(stringType);
        dep.use();

        dependencyAnalyzer.linkField(new FieldReference(String.class.getName(), "characters"));

        dep = dependencyAnalyzer.linkMethod(new MethodReference(Object.class, "toString", String.class));
        dep.getVariable(0).propagate(dependencyAnalyzer.getClassType("java.lang.Object"));
        dep.use();

        var exceptionCons = dependencyAnalyzer.linkMethod(new MethodReference(
                RuntimeException.class, "<init>", String.class, void.class));
        exceptionCons.getVariable(0).propagate(dependencyAnalyzer.getClassType(RuntimeException.class.getName()));
        exceptionCons.getVariable(1).propagate(stringType);
        exceptionCons.use();

        if (strict) {
            exceptionCons = dependencyAnalyzer.linkMethod(new MethodReference(
                    ArrayIndexOutOfBoundsException.class, "<init>", void.class));
            exceptionCons.getVariable(0).propagate(dependencyAnalyzer.getClassType(
                    ArrayIndexOutOfBoundsException.class.getName()));
            exceptionCons.use();

            exceptionCons = dependencyAnalyzer.linkMethod(new MethodReference(
                    NullPointerException.class, "<init>", void.class));
            exceptionCons.getVariable(0).propagate(dependencyAnalyzer.getClassType(
                    NullPointerException.class.getName()));
            exceptionCons.use();

            exceptionCons = dependencyAnalyzer.linkMethod(new MethodReference(
                    ClassCastException.class, "<init>", void.class));
            exceptionCons.getVariable(0).propagate(dependencyAnalyzer.getClassType(ClassCastException.class.getName()));
            exceptionCons.use();
        }

        if (stackTraceIncluded) {
            includeStackTraceMethods(dependencyAnalyzer);
        }

        dependencyAnalyzer.linkMethod(new MethodReference(Throwable.class, "getMessage", String.class)).use();
        dependencyAnalyzer.linkMethod(new MethodReference(Throwable.class, "getCause", Throwable.class)).use();

        dependencyAnalyzer.addDependencyListener(new AbstractDependencyListener() {
            @Override
            public void methodReached(DependencyAgent agent, MethodDependency method) {
                if (method.getReference().equals(CURRENT_THREAD)) {
                    method.use();
                    agent.linkMethod(new MethodReference(Thread.class, "setCurrentThread", Thread.class, void.class))
                            .use();
                }
            }
        });

        dependencyAnalyzer.addDependencyListener(new WeakReferenceDependencyListener());
        dependencyAnalyzer.addDependencyListener(reflection);
    }

    public static void includeStackTraceMethods(DependencyAnalyzer dependencyAnalyzer) {
        MethodDependency dep;

        DependencyType stringType = dependencyAnalyzer.getClassType("java.lang.String");

        dep = dependencyAnalyzer.linkMethod(new MethodReference(
                StackTraceElement.class, "<init>", String.class, String.class, String.class,
                int.class, void.class));
        dep.getVariable(0).propagate(dependencyAnalyzer.getClassType(StackTraceElement.class.getName()));
        dep.getVariable(1).propagate(stringType);
        dep.getVariable(2).propagate(stringType);
        dep.getVariable(3).propagate(stringType);
        dep.use();

        dep = dependencyAnalyzer.linkMethod(new MethodReference(
                Throwable.class, "setStackTrace", StackTraceElement[].class, void.class));
        dep.getVariable(0).propagate(dependencyAnalyzer.getClassType(Throwable.class.getName()));
        dep.getVariable(1).propagate(dependencyAnalyzer.getType(ValueType.parse(StackTraceElement[].class)));
        dep.getVariable(1).getArrayItem().propagate(dependencyAnalyzer.getClassType(StackTraceElement.class.getName()));
        dep.use();
    }

    @Override
    public void emit(ListableClassHolderSource classes, BuildTarget target, String outputName) {
        try (OutputStream output = target.createResource(outputName);
                Writer writer = new OutputStreamWriter(output, StandardCharsets.UTF_8)) {
            emit(classes, writer, target);
        } catch (IOException e) {
            throw new RenderingException(e);
        }
    }

    @Override
    public void beforeInlining(Program program, MethodReader method) {
        if (strict) {
            nullCheckInsertion.transformProgram(program, method.getReference());
        }
    }

    @Override
    public void beforeOptimizations(Program program, MethodReader method) {
        if (strict) {
            boundCheckInsertion.transformProgram(program, method.getReference());
        }
    }

    @Override
    public void afterOptimizations(Program program, MethodReader method) {
    }

    private void emit(ListableClassHolderSource classes, Writer writer, BuildTarget target) {
        AliasProvider aliasProvider;
        if (deterministicNames) {
            aliasProvider = new DeterministicAliasProvider(maxTopLevelNames);
        } else if (obfuscated) {
            aliasProvider = new MinifyingAliasProvider(maxTopLevelNames);
        } else {
            aliasProvider = new DefaultAliasProvider(maxTopLevelNames);
        }
        DefaultNamingStrategy naming = new DefaultNamingStrategy(aliasProvider, controller.getUnprocessedClassSource());
        DebugInformationEmitter debugEmitterToUse = debugEmitter;
        if (debugEmitterToUse == null) {
            debugEmitterToUse = new DummyDebugInformationEmitter();
        }

        var methodContributorContext = new MethodContributorContextImpl(classes);
        RenderingContext renderingContext = new RenderingContext(debugEmitterToUse,
                controller.getUnprocessedClassSource(), classes, controller.getResourceProvider(),
                controller.getClassLoader(), controller.getServices(), controller.getProperties(), naming,
                controller.getDependencyInfo(),
                m -> isVirtual(methodContributorContext, m),
                m -> isForcedFunction(methodContributorContext, m),
                controller.getClassInitializerInfo(), strict
        ) {
            @Override
            public String importModule(String name) {
                return JavaScriptTarget.this.importModule(name);
            }

            @Override
            public Set<String> getImportedClasses() {
                return importedRuntime != null
                        ? new HashSet<>(importedRuntime.getClassNames())
                        : Collections.emptySet();
            }
        };
        renderingContext.setMinifying(obfuscated);
        new ReflectionIntrinsics(methodInjectors, methodGenerators, injectorProviders, classes, reflection,
                controller.getDependencyInfo()).apply();

        if (controller.wasCancelled()) {
            return;
        }

        var builder = new OutputSourceWriterBuilder(naming);
        builder.setMinified(obfuscated);

        for (var className : classes.getClassNames()) {
            var cls = classes.get(className);
            for (var method : cls.getMethods()) {
                preprocessNativeMethod(method);
            }
        }
        for (var entry : methodInjectors.entrySet()) {
            renderingContext.addInjector(entry.getKey(), entry.getValue());
        }

        var rememberingWriter = new RememberingSourceWriter(debugEmitter != null);
        var metadataWriter = new RememberingSourceWriter(debugEmitter != null);
        var renderer = new Renderer(rememberingWriter, metadataWriter, asyncMethods, renderingContext,
                controller.getDiagnostics(), methodGenerators, astCache, controller.getCacheStatus(),
                templateFactory, exports, controller.getEntryPoint());
        renderer.setProperties(controller.getProperties());
        renderer.setProgressConsumer(controller::reportProgress);

        for (var listener : rendererListeners) {
            listener.begin(renderer, target);
        }
        if (!renderer.render(classes, controller.isFriendlyToDebugger())) {
            return;
        }
        var declarations = rememberingWriter.save();
        rememberingWriter.clear();
        var metadata = metadataWriter.save();
        metadataWriter.clear();

        renderer.renderStringPool();
        renderer.renderStringConstants();
        renderer.renderCompatibilityStubs();
        emitMainMethod(classes, rememberingWriter);

        for (var listener : rendererListeners) {
            listener.complete();
        }
        var epilogue = rememberingWriter.save();
        rememberingWriter.clear();

        var runtimeRenderer = new RuntimeRenderer(classes, rememberingWriter, controller.getClassInitializerInfo());
        runtimeRenderer.prepareAstParts(renderer.isThreadLibraryUsed());
        declarations.replay(runtimeRenderer.sink, RememberedSource.FILTER_REF);
        metadata.replay(runtimeRenderer.sink, RememberedSource.FILTER_REF);
        epilogue.replay(runtimeRenderer.sink, RememberedSource.FILTER_REF);
        if (sharedRuntimeClasses.isEmpty()) {
            runtimeRenderer.removeUnusedParts();
        }
        if (importedRuntime != null) {
            runtimeRenderer.retainPerModuleParts();
        }
        runtimeRenderer.renderRuntime();
        var runtime = rememberingWriter.save();
        rememberingWriter.clear();
        runtimeRenderer.renderEpilogue();
        var runtimeEpilogue = rememberingWriter.save();
        rememberingWriter.clear();

        naming.additionalScopeName();
        naming.functionName("$rt_exports");
        for (var module : importedModules.values()) {
            naming.functionName(module);
        }
        for (var export : exports) {
            export.nameFreq.accept(naming);
        }
        var frequencyEstimator = new NameFrequencyEstimator();
        runtime.replay(frequencyEstimator, RememberedSource.FILTER_REF);
        runtimeEpilogue.replay(frequencyEstimator, RememberedSource.FILTER_REF);
        declarations.replay(frequencyEstimator, RememberedSource.FILTER_REF);
        metadata.replay(frequencyEstimator, RememberedSource.FILTER_REF);
        epilogue.replay(frequencyEstimator, RememberedSource.FILTER_REF);
        frequencyEstimator.apply(naming);

        // Every alias exists only once the frequency estimator has minted it, so neither mode can
        // know its own list before this point.
        if (importedRuntime != null) {
            var exported = new HashSet<>(importedRuntime.getAliases());
            // The runtime module owns the $rt_* functions as well as the classes, and this module
            // renders only the per-module ones, so every other one it can reach has to be imported.
            for (var name : runtimeRenderer.getTopLevelNames()) {
                if (exported.contains(name) && !RuntimeRenderer.PER_MODULE_NAMES.contains(name)) {
                    importedAliases.add(name);
                }
            }
            for (var alias : ((DeterministicAliasProvider) aliasProvider).getDeclaredTopLevelAliases()) {
                if (exported.contains(alias)) {
                    importedAliases.add(alias);
                }
            }
        }
        // Every alias exists only once the frequency estimator has minted it, so a shared runtime
        // can only know what it declares from here on.
        if (!sharedRuntimeClasses.isEmpty()) {
            // FILTER_ALL, not FILTER_REF: the declaration markers are not references, and filtering
            // them out leaves the collector unable to tell a declaration from a use.
            var collector = new DeclarationCollector(naming);
            runtime.replay(collector, RememberedSource.FILTER_ALL);
            declarations.replay(collector, RememberedSource.FILTER_ALL);
            metadata.replay(collector, RememberedSource.FILTER_ALL);
            runtimeEpilogue.replay(collector, RememberedSource.FILTER_ALL);
            epilogue.replay(collector, RememberedSource.FILTER_ALL);
            emittedClassNames.addAll(classes.getClassNames());
            emittedTopLevelAliases.addAll(collector.getDeclared());
            // In this mode removeUnusedParts is skipped, so every name the hand-written parts
            // declare is present whether or not the collector saw its declaration marker.
            emittedTopLevelAliases.addAll(runtimeRenderer.getTopLevelNames());
            // The per-module names are declared but withheld: a consumer renders its own, and
            // leaving them out of the manifest is what makes importing one a gate failure rather
            // than silent state corruption.
            emittedTopLevelAliases.removeAll(RuntimeRenderer.PER_MODULE_NAMES);
            // A module's entry export names its OWN main, so the runtime's names the runtime's.
            // Offering it would let a consumer bind the wrong function under a name it also declares.
            emittedTopLevelAliases.remove(MAIN_EXPORT_ALIAS);
            for (var alias : emittedTopLevelAliases) {
                exports.add(new ExportedDeclaration(w -> w.append(alias), n -> { }, alias));
            }
        }

        var sourceWriter = builder.build(writer);
        sourceWriter.setDebugInformationEmitter(debugEmitterToUse);
        printWrapperStart(sourceWriter);
        if (frequencyEstimator.hasAdditionalScope()) {
            sourceWriter.append("let ").append(naming.additionalScopeName()).ws().append('=').ws()
                    .append("{};").softNewLine();
        }

        int start = sourceWriter.getOffset();
        runtime.write(sourceWriter, 0);
        declarations.write(sourceWriter, 0);
        metadata.write(sourceWriter, 0);
        runtimeEpilogue.write(sourceWriter, 0);
        epilogue.write(sourceWriter, 0);

        printModuleEnd(sourceWriter);
        sourceWriter.finish();

        int totalSize = sourceWriter.getOffset() - start;
        printStats(sourceWriter, totalSize);
    }

    private void emitMainMethod(ClassReaderSource classes, SourceWriter writer) {
        var alias = MAIN_EXPORT_ALIAS;
        var ref = new MethodReference(controller.getEntryPoint(), TeaVM.MAIN_METHOD_DESC);
        var mainMethod = classes.resolve(ref);
        var hasMainMethod = false;
        var instanceEntryPoint = false;

        if (mainMethod != null) {
            instanceEntryPoint = !mainMethod.hasModifier(ElementModifier.STATIC);
            hasMainMethod = true;
        } else {
            ref = new MethodReference(controller.getEntryPoint(), TeaVM.SHORT_MAIN_METHOD_DESC);
            mainMethod = classes.resolve(ref);
            if (mainMethod != null) {
                instanceEntryPoint = true;
                hasMainMethod = true;
            }
        }
        if (hasMainMethod) {
            if (instanceEntryPoint) {
                writer.startVariableDeclaration().appendFunction(alias)
                        .appendFunction("$rt_instanceMainStarter").append("(").appendMethod(ref)
                        .append(",").ws().appendMethod(controller.getEntryPoint(), "<init>", ValueType.VOID)
                        .append(",").ws().appendClass(controller.getEntryPoint()).append(")").endDeclaration();
            } else {
                writer.startVariableDeclaration().appendFunction(alias)
                        .appendFunction("$rt_mainStarter").append("(").appendMethod(ref);
                writer.append(")").endDeclaration();
            }
            writer.appendFunction(alias).append(".")
                    .append("javaException").ws().append("=").ws().appendFunction("$rt_javaException")
                    .append(";").newLine();
            exports.add(new ExportedDeclaration(w -> w.appendFunction(alias),
                    n -> n.functionName(alias), controller.getEntryPointName()));
        }
    }

    private void printWrapperStart(SourceWriter writer) {
        writer.append("\"use strict\";").newLine();
        printModuleStart(writer);
    }

    private String importModule(String name) {
        return importedModules.computeIfAbsent(name, n -> "$rt_imported_" + importedModules.size());
    }

    private void printModuleStart(SourceWriter writer) {
        switch (moduleType) {
            case UMD:
                printUmdStart(writer);
                break;
            case COMMON_JS:
                printCommonJsStart(writer);
                break;
            case NONE:
                printIIFStart(writer);
                break;
            case ES2015:
                printES2015Start(writer);
                break;
        }
    }

    private void printUmdStart(SourceWriter writer) {
        writer.append("(function(module)").appendBlockStart();
        writer.appendIf().append("typeof define").ws().append("===").ws().append("'function'")
                .ws().append("&&").ws().append("define.amd)").appendBlockStart();
        writer.append("define(['exports'");
        for (var moduleName : importedModules.keySet()) {
            writer.append(',').ws().append('"').append(RenderingUtil.escapeString(moduleName)).append('"');
        }
        writer.append("],").ws().append("function(exports");
        for (var moduleAlias : importedModules.values()) {
            writer.append(',').ws().appendFunction(moduleAlias);
        }
        writer.append(")").ws().appendBlockStart();
        writer.append("module(exports");
        for (var moduleAlias : importedModules.values()) {
            writer.append(',').ws().appendFunction(moduleAlias);
        }
        writer.append(");").softNewLine();
        writer.outdent().append("});").softNewLine();

        writer.appendElseIf().append("typeof exports").ws()
                .append("===").ws().append("'object'").ws().append("&&").ws()
                .append("exports").ws().append("!==").ws().append("null").ws().append("&&").ws()
                .append("typeof exports.nodeName").ws().append("!==").ws().append("'string')").appendBlockStart();
        writer.append("module(exports");
        for (var moduleName : importedModules.keySet()) {
            writer.append(',').ws().append("require(\"").append(RenderingUtil.escapeString(moduleName)).append("\")");
        }
        writer.append(");").softNewLine();

        writer.appendElse();
        writer.append("module(");
        writer.outdent().append("typeof self").ws().append("!==").ws().append("'undefined'")
                .ws().append("?").ws().append("self")
                .ws().append(":").ws().append("this");

        writer.append(");").softNewLine();
        writer.appendBlockEnd();
        writer.outdent().append("}(");

        writer.append("function(").appendFunction("$rt_exports");
        for (var moduleName : importedModules.values()) {
            writer.append(",").ws().appendFunction(moduleName);
        }
        writer.append(")").appendBlockStart();
    }

    private void printIIFStart(SourceWriter writer) {
        for (var export : exports) {
            writer.append("var ").appendGlobal(export.alias).append(";").softNewLine();
        }
        writer.append("(function()").appendBlockStart();

        for (var entry : importedModules.entrySet()) {
            var moduleName = entry.getKey();
            var alias = entry.getValue();
            writer.append("let ").appendFunction(alias).ws().append('=').ws().append("this[\"")
                    .append(RenderingUtil.escapeString(moduleName)).append("\"];").softNewLine();
        }
    }

    private void printCommonJsStart(SourceWriter writer) {
        for (var entry : importedModules.entrySet()) {
            var moduleName = entry.getKey();
            var alias = entry.getValue();
            writer.append("let ").appendFunction(alias).ws().append('=').ws().append("require(\"")
                    .append(RenderingUtil.escapeString(moduleName)).append("\");").softNewLine();
        }
    }

    private void printES2015Start(SourceWriter writer) {
        if (importedRuntime != null) {
            writer.append("import").ws().append("{").ws();
            var first = true;
            for (var alias : importedAliases) {
                if (!first) {
                    writer.append(",").ws();
                }
                first = false;
                writer.append(alias);
            }
            writer.ws().append("}").ws().append("from").ws().append("\"")
                    .append(RenderingUtil.escapeString(importedRuntimeModule)).append("\";")
                    .softNewLine();
        }
        for (var entry : importedModules.entrySet()) {
            var moduleName = entry.getKey();
            var alias = entry.getValue();
            writer.append("import").ws().append("*").ws().append("as ").appendFunction(alias)
                    .append(" from").ws().append("\"")
                    .append(RenderingUtil.escapeString(moduleName)).append("\";").softNewLine();
        }
    }

    private void printModuleEnd(SourceWriter writer) {
        switch (moduleType) {
            case UMD:
                printUmdEnd(writer);
                break;
            case COMMON_JS:
                printCommonJsEnd(writer);
                break;
            case NONE:
                printIFFEnd(writer);
                break;
            case ES2015:
                printES2015End(writer);
                break;
        }
    }

    private void printUmdEnd(SourceWriter writer) {
        for (var export : exports) {
            writer.appendFunction("$rt_exports").append(".").append(export.alias).ws()
                    .append("=").ws();
            export.name.accept(writer);
            writer.append(";").softNewLine();
        }
        writer.outdent().append("}));").newLine();
    }

    private void printCommonJsEnd(SourceWriter writer) {
        for (var export : exports) {
            writer.append("exports.").append(export.alias).ws().append("=").ws();
            export.name.accept(writer);
            writer.append(";").softNewLine();
        }
    }

    private void printIFFEnd(SourceWriter writer) {
        for (var export : exports) {
            writer.appendGlobal(export.alias).ws().append("=").ws();
            export.name.accept(writer);
            writer.append(";").softNewLine();
        }
        writer.outdent().append("})();");
    }

    private void printES2015End(SourceWriter writer) {
        writer.append("export").ws().append("{").ws();
        var first = true;
        for (var export : exports) {
            if (!first) {
                writer.append(",").ws();
            }
            first = false;
            export.name.accept(writer);
            writer.append(" as ").append(export.alias);
        }
        writer.ws().append("};").softNewLine();
    }

    private void printStats(OutputSourceWriter writer, int totalSize) {
        if (!Boolean.parseBoolean(System.getProperty("teavm.js.stats", "false"))) {
            return;
        }

        System.out.println("Total output size: " + STATS_NUM_FORMAT.format(totalSize));
        System.out.println("Metadata size: " + getSizeWithPercentage(
                writer.getSectionSize(Renderer.SECTION_METADATA), totalSize));
        System.out.println("String pool size: " + getSizeWithPercentage(
                writer.getSectionSize(Renderer.SECTION_STRING_POOL), totalSize));

        var packageSizeMap = new ObjectIntHashMap<String>();
        for (String className : writer.getClassesInStats()) {
            String packageName = className.substring(0, className.lastIndexOf('.') + 1);
            int classSize = writer.getClassSize(className);
            packageSizeMap.put(packageName, packageSizeMap.getOrDefault(packageName, 0) + classSize);
        }

        String[] packageNames = packageSizeMap.keys().toArray(String.class);
        Arrays.sort(packageNames, Comparator.comparing(p -> -packageSizeMap.getOrDefault(p, 0)));
        for (String packageName : packageNames) {
            System.out.println("Package '" + packageName + "' size: "
                    + getSizeWithPercentage(packageSizeMap.get(packageName), totalSize));
        }
    }

    private String getSizeWithPercentage(int size, int totalSize) {
        return STATS_NUM_FORMAT.format(size) + " (" + STATS_PERCENT_FORMAT.format((double) size / totalSize) + ")";
    }

    private void preprocessNativeMethod(MethodHolder method) {
        if (!method.getModifiers().contains(ElementModifier.NATIVE)
                || methodGenerators.get(method.getReference()) != null
                || methodInjectors.get(method.getReference()) != null) {
            return;
        }

        boolean found = false;
        ProviderContext context = new ProviderContextImpl(method.getReference());
        for (var provider : generatorProviders) {
            Generator generator = provider.apply(context);
            if (generator != null) {
                methodGenerators.put(method.getReference(), generator);
                found = true;
                break;
            }
        }
        for (var provider : injectorProviders) {
            Injector injector = provider.apply(context);
            if (injector != null) {
                methodInjectors.put(method.getReference(), injector);
                found = true;
                break;
            }
        }

        if (found) {
            return;
        }

        if (!isBootstrap()) {
            if (method.getAnnotations().get(GeneratedBy.class.getName()) != null
                    || method.getAnnotations().get(InjectedBy.class.getName()) != null) {
                return;
            }
        }
        method.getModifiers().remove(ElementModifier.NATIVE);

        Program program = new Program();
        method.setProgram(program);

        for (int i = 0; i <= method.parameterCount(); ++i) {
            program.createVariable();
        }

        BasicBlock block = program.createBasicBlock();
        Variable exceptionVar = program.createVariable();
        ConstructInstruction newExceptionInsn = new ConstructInstruction();
        newExceptionInsn.setType(NoSuchMethodError.class.getName());
        newExceptionInsn.setReceiver(exceptionVar);
        block.add(newExceptionInsn);

        Variable constVar = program.createVariable();
        StringConstantInstruction constInsn = new StringConstantInstruction();
        constInsn.setConstant("Native method implementation not found: " + method.getReference());
        constInsn.setReceiver(constVar);
        block.add(constInsn);

        InvokeInstruction initExceptionInsn = new InvokeInstruction();
        initExceptionInsn.setInstance(exceptionVar);
        initExceptionInsn.setMethod(new MethodReference(NoSuchMethodError.class, "<init>", String.class, void.class));
        initExceptionInsn.setType(InvocationType.SPECIAL);
        initExceptionInsn.setArguments(constVar);
        block.add(initExceptionInsn);

        RaiseInstruction raiseInsn = new RaiseInstruction();
        raiseInsn.setException(exceptionVar);
        block.add(raiseInsn);

        controller.getDiagnostics().error(new CallLocation(method.getReference()),
                "Native method {{m0}} has no implementation",  method.getReference());
    }

    class ProviderContextImpl implements ProviderContext {
        private MethodReference method;

        ProviderContextImpl(MethodReference method) {
            this.method = method;
        }

        @Override
        public MethodReference getMethod() {
            return method;
        }

        @Override
        public ClassReaderSource getClassSource() {
            return controller.getUnprocessedClassSource();
        }

        @Override
        public <T> T getService(Class<T> type) {
            return controller.getServices().getService(type);
        }
    }

    @PlatformMarker
    private static boolean isBootstrap() {
        return false;
    }

    private void emitCFG(DebugInformationEmitter emitter, ControlFlowEntry[] cfg) {
        for (ControlFlowEntry entry : cfg) {
            SourceLocation location = map(entry.from);
            SourceLocation[] successors = new SourceLocation[entry.to.length];
            for (int i = 0; i < entry.to.length; ++i) {
                successors[i] = map(entry.to[i]);
            }
            emitter.addSuccessors(location, successors);
        }
    }

    private static SourceLocation map(TextLocation location) {
        if (location == null || location.isEmpty()) {
            return null;
        }
        return new SourceLocation(location.getFileName(), location.getLine());
    }

    @Override
    public String[] getPlatformTags() {
        return new String[] { Platforms.JAVASCRIPT };
    }

    @Override
    public void addVirtualMethods(MethodContributor virtualMethods) {
        customVirtualMethods.add(virtualMethods);
    }

    @Override
    public void addForcedFunctionMethods(MethodContributor forcedFunctionMethods) {
        this.forcedFunctionMethods.add(forcedFunctionMethods);
    }

    @Override
    public boolean isAsyncSupported() {
        return true;
    }

    private boolean isVirtual(MethodContributorContext context, MethodReference method) {
        if (controller.isVirtual(method)) {
            return true;
        }
        for (MethodContributor predicate : customVirtualMethods) {
            if (predicate.isContributing(context, method)) {
                return true;
            }
        }
        return false;
    }

    private boolean isForcedFunction(MethodContributorContext context, MethodReference method) {
        for (var predicate : forcedFunctionMethods) {
            if (predicate.isContributing(context, method)) {
                return true;
            }
        }
        return false;
    }

    private static class MethodContributorContextImpl implements MethodContributorContext {
        private ClassReaderSource classSource;

        MethodContributorContextImpl(ClassReaderSource classSource) {
            this.classSource = classSource;
        }

        @Override
        public ClassReaderSource getClassSource() {
            return classSource;
        }
    }
}
