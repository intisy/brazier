/*
 *  Copyright 2026 Alexey Andreev.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package org.teavm.backend.wasm.intrinsics.reflection;

import org.teavm.ast.InvocationExpr;
import org.teavm.backend.wasm.generate.classes.WasmGCClassInfoProvider;
import org.teavm.backend.wasm.intrinsics.WasmGCInlineIntrinsic;
import org.teavm.backend.wasm.intrinsics.WasmGCInlineIntrinsicContext;
import org.teavm.backend.wasm.model.instruction.WasmInstructionBuilder;
import org.teavm.backend.wasm.model.instruction.WasmSignedType;
import org.teavm.model.ElementModifier;
import org.teavm.model.ListableClassReaderSource;
import org.teavm.model.ValueType;

public class AnnotationDataIntrinsic implements WasmGCInlineIntrinsic {
    private final WasmGCClassInfoProvider classInfoProvider;
    private final ListableClassReaderSource classes;
    private final String annotationClassName;

    public AnnotationDataIntrinsic(WasmGCClassInfoProvider classInfoProvider, ListableClassReaderSource classes,
            String annotationClassName) {
        this.classInfoProvider = classInfoProvider;
        this.classes = classes;
        this.annotationClassName = annotationClassName;
    }

    @Override
    public void apply(InvocationExpr invocation, WasmGCInlineIntrinsicContext context,
            WasmInstructionBuilder builder) {
        var dataStruct = classInfoProvider.reflectionTypes().annotationData(annotationClassName);
        if (invocation.getMethod().getName().equals("constructor") && invocation.getArguments().isEmpty()) {
            var fn = dataStruct.constructor();
            fn.setReferenced(true);
            builder.funcRef(fn);
            return;
        }

        var field = dataStruct.field(invocation.getMethod().getName());
        context.generate(builder, invocation.getArguments().get(0));
        WasmSignedType signedType = null;
        if (field.type instanceof ValueType.Primitive) {
            switch (((ValueType.Primitive) field.type).getKind()) {
                case BOOLEAN:
                case BYTE:
                case SHORT:
                    signedType = WasmSignedType.SIGNED;
                    break;
                case CHARACTER:
                    signedType = WasmSignedType.UNSIGNED;
                    break;
                default:
                    break;
            }
        } else if (field.type instanceof ValueType.Object) {
            var fieldCls = classes.get(((ValueType.Object) field.type).getClassName());
            if (fieldCls != null && fieldCls.hasModifier(ElementModifier.ENUM)) {
                signedType = WasmSignedType.SIGNED;
            }
        }
        builder.structGet(dataStruct.structure(), field.index, signedType);
    }
}
