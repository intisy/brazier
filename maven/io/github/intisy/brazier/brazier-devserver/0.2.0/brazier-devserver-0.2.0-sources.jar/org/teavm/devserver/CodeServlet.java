/*
 *  Copyright 2018 Alexey Andreev.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package org.teavm.devserver;

import jakarta.servlet.AsyncContext;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import org.eclipse.jetty.client.HttpClient;
import org.eclipse.jetty.client.InputStreamRequestContent;
import org.eclipse.jetty.client.Request;
import org.eclipse.jetty.client.Response;
import org.eclipse.jetty.ee10.websocket.server.JettyWebSocketServlet;
import org.eclipse.jetty.ee10.websocket.server.JettyWebSocketServletFactory;
import org.eclipse.jetty.http.HttpField;
import org.eclipse.jetty.websocket.client.ClientUpgradeRequest;
import org.eclipse.jetty.websocket.client.WebSocketClient;
import org.teavm.backend.javascript.JSModuleType;
import org.teavm.cache.InMemoryMethodNodeCache;
import org.teavm.cache.InMemoryProgramCache;
import org.teavm.cache.InMemorySymbolTable;
import org.teavm.cache.MemoryCachedClassReaderSource;
import org.teavm.dependency.FastDependencyAnalyzer;
import org.teavm.model.ClassReader;
import org.teavm.model.ClassReaderSource;
import org.teavm.model.PreOptimizingClassHolderSource;
import org.teavm.model.ReferenceCache;
import org.teavm.parsing.RenamingClassHolderSource;
import org.teavm.parsing.resource.ResourceBytecodeClassHolderSource;
import org.teavm.parsing.resource.ResourceProvider;
import org.teavm.parsing.substitution.DefaultSubstituteClassNameMapping;
import org.teavm.tooling.EmptyTeaVMToolLog;
import org.teavm.tooling.TeaVMProblemRenderer;
import org.teavm.tooling.TeaVMToolLog;
import org.teavm.tooling.builder.BuildResult;
import org.teavm.tooling.builder.SimpleBuildResult;
import org.teavm.tooling.util.FileSystemWatcher;
import org.teavm.vm.MemoryBuildTarget;
import org.teavm.vm.TeaVM;
import org.teavm.vm.TeaVMBuilder;
import org.teavm.vm.TeaVMOptimizationLevel;
import org.teavm.vm.TeaVMPhase;
import org.teavm.vm.TeaVMProgressFeedback;
import org.teavm.vm.TeaVMProgressListener;
import org.teavm.vm.TeaVMTarget;

public class CodeServlet extends JettyWebSocketServlet {
    private static final Supplier<InputStream> EMPTY_CONTENT = () -> null;

    private String mainClass;
    private String[] classPath;
    private String fileName = "classes.js";
    private String pathToFile = "/";
    private String indicatorWsPath;
    private String deobfuscatorPath;
    private List<String> sourcePath = new ArrayList<>();
    private TeaVMToolLog log = new EmptyTeaVMToolLog();
    private boolean indicator;
    private boolean deobfuscateStack;
    private boolean automaticallyReloaded;
    private int port;
    private int debugPort;
    private String proxyUrl;
    private String proxyPath = "/";
    private String proxyHost;
    private String proxyProtocol;
    private int proxyPort;
    private String proxyBaseUrl;
    private List<String> staticFileRoots = new ArrayList<>();
    private String staticFilesPath = "";
    private List<String> resourcesRoots = new ArrayList<>();
    private String resourcesPath = "";
    private List<ZipFile> resourceZipFiles;
    private List<File> resourceDirs;
    private Map<String, String> properties = new LinkedHashMap<>();
    private List<String> preservedClasses = new ArrayList<>();
    private JSModuleType jsModuleType;
    private boolean wasmSharedBuffer;
    private boolean wasmModularRuntime;

    private Map<String, Supplier<InputStream>> sourceFileCache = new HashMap<>();

    private volatile boolean stopped;
    private FileSystemWatcher watcher;
    private MemoryCachedClassReaderSource classSource;
    private InMemoryProgramCache programCache;
    private InMemoryMethodNodeCache astCache;
    private int lastReachedClasses;
    private boolean firstTime = true;

    private final Object contentLock = new Object();
    private final Map<String, byte[]> content = new HashMap<>();
    private MemoryBuildTarget buildTarget = new MemoryBuildTarget();

    private final Set<ProgressHandler> progressHandlers = new LinkedHashSet<>();
    private final Object statusLock = new Object();
    private volatile boolean cancelRequested;
    private boolean compiling;
    private double progress;
    private boolean waiting;
    private Thread buildThread;
    private List<DevServerListener> listeners = new ArrayList<>();
    private HttpClient httpClient;
    private WebSocketClient wsClient = new WebSocketClient();
    private InMemorySymbolTable symbolTable = new InMemorySymbolTable();
    private InMemorySymbolTable fileSymbolTable = new InMemorySymbolTable();
    private InMemorySymbolTable variableSymbolTable = new InMemorySymbolTable();
    private ReferenceCache referenceCache = new ReferenceCache();
    private boolean fileSystemWatched = true;
    private boolean compileOnStartup = true;
    private boolean logBuildErrors = true;

    private Map<String, CachedEntry> fileCache = new HashMap<>();
    private Map<String, CachedEntry> resourceCache = new HashMap<>();

    private CodeServletBackend<?> backend = new CodeServletJavaScriptBackend();

    public CodeServlet(String mainClass, String[] classPath) {
        this.mainClass = mainClass;
        this.classPath = classPath != null ? classPath.clone() : new String[0];

        httpClient = new HttpClient();
        httpClient.setFollowRedirects(false);
    }

    @Override
    protected void configure(JettyWebSocketServletFactory factory) {
        factory.setCreator((req, resp) -> {
            ProxyWsClient proxyClient = (ProxyWsClient) req.getHttpServletRequest().getAttribute("teavm.ws.client");
            if (proxyClient == null) {
                return new CodeWsEndpoint(this);
            } else {
                ProxyWsClient proxy = new ProxyWsClient();
                proxy.setTarget(proxyClient);
                proxyClient.setTarget(proxy);
                return proxy;
            }
        });
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setPathToFile(String pathToFile) {
        this.pathToFile = normalizePath(pathToFile);
    }

    public List<String> getSourcePath() {
        return sourcePath;
    }

    public void setLog(TeaVMToolLog log) {
        this.log = log;
    }

    public void setIndicator(boolean indicator) {
        this.indicator = indicator;
    }

    public void setDeobfuscateStack(boolean deobfuscateStack) {
        this.deobfuscateStack = deobfuscateStack;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public void setDebugPort(int debugPort) {
        this.debugPort = debugPort;
    }

    public void setAutomaticallyReloaded(boolean automaticallyReloaded) {
        this.automaticallyReloaded = automaticallyReloaded;
    }

    public void setProxyUrl(String proxyUrl) {
        this.proxyUrl = proxyUrl;
    }

    public void setProxyPath(String proxyPath) {
        this.proxyPath = normalizePath(proxyPath);
    }

    public void setStaticFileRoots(List<String> staticFileRoots) {
        this.staticFileRoots = List.copyOf(staticFileRoots);
    }

    public void setStaticFilesPath(String staticFilesPath) {
        if (staticFilesPath.startsWith("/")) {
            staticFilesPath = staticFilesPath.substring(1);
        }
        if (staticFilesPath.endsWith("/")) {
            staticFilesPath = staticFilesPath.substring(0, staticFilesPath.length() - 1);
        }
        this.staticFilesPath = staticFilesPath;
    }

    public void setResourcesRoots(List<String> resourcesRoots) {
        this.resourcesRoots = List.copyOf(resourcesRoots);
    }

    public void setResourcesPath(String resourcesPath) {
        if (resourcesPath.startsWith("/")) {
            resourcesPath = resourcesPath.substring(1);
        }
        if (resourcesPath.endsWith("/")) {
            resourcesPath = resourcesPath.substring(0, resourcesPath.length() - 1);
        }
        this.resourcesPath = resourcesPath;
    }

    public void setFileSystemWatched(boolean fileSystemWatched) {
        this.fileSystemWatched = fileSystemWatched;
    }

    public void setCompileOnStartup(boolean compileOnStartup) {
        this.compileOnStartup = compileOnStartup;
    }

    public List<String> getPreservedClasses() {
        return preservedClasses;
    }

    public Map<String, String> getProperties() {
        return properties;
    }

    public void setWasmSharedBuffer(boolean wasmSharedBuffer) {
        this.wasmSharedBuffer = wasmSharedBuffer;
    }

    public void setWasmModularRuntime(boolean wasmModularRuntime) {
        this.wasmModularRuntime = wasmModularRuntime;
    }

    public void setJsModuleType(JSModuleType jsModuleType) {
        this.jsModuleType = jsModuleType;
    }

    public void setLogBuildErrors(boolean logBuildErrors) {
        this.logBuildErrors = logBuildErrors;
    }

    public void setBackend(CodeServletBackend<?> backend) {
        this.backend = backend;
    }

    public void addProgressHandler(ProgressHandler handler) {
        synchronized (progressHandlers) {
            progressHandlers.add(handler);
        }

        double progress;
        synchronized (statusLock) {
            if (!compiling) {
                return;
            }
            progress = this.progress;
        }

        handler.progress(progress);
    }

    public void removeProgressHandler(ProgressHandler handler) {
        synchronized (progressHandlers) {
            progressHandlers.remove(handler);
        }
    }

    public void addListener(DevServerListener listener) {
        listeners.add(listener);
    }

    public void invalidateCache() {
        synchronized (statusLock) {
            if (compiling) {
                return;
            }
            astCache.invalidate();
            programCache.invalidate();
            classSource.invalidate();
            symbolTable.invalidate();
            fileSymbolTable.invalidate();
        }
    }

    public void buildProject() {
        if (buildThread == null) {
            runCompilerThread();
        } else {
            synchronized (statusLock) {
                if (waiting) {
                    buildThread.interrupt();
                }
            }
        }
    }

    public void cancelBuild() {
        synchronized (statusLock) {
            if (compiling) {
                cancelRequested = true;
            }
        }
    }

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);

        if (proxyUrl != null) {
            try {
                httpClient.start();
                wsClient.start();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

            try {
                URL url = new URL(proxyUrl);
                proxyPort = url.getPort();
                proxyHost = proxyPort >= 0 ? url.getHost() + ":" + proxyPort : url.getHost();
                proxyProtocol = url.getProtocol();

                StringBuilder sb = new StringBuilder();
                sb.append(proxyProtocol).append("://").append(proxyHost);
                proxyBaseUrl = sb.toString();
            } catch (MalformedURLException e) {
                log.warning("Could not extract host from URL: " + proxyUrl, e);
            }
        }

        indicatorWsPath = pathToFile + fileName + ".ws";
        deobfuscatorPath = pathToFile + fileName + ".deobfuscator.js";
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        String path = req.getRequestURI();
        if (path != null) {
            log.debug("Serving " + path);
            if (!path.startsWith("/")) {
                path = "/" + path;
            }
            if ((req.getMethod().equals("GET") || req.getMethod().equals("OPTIONS"))
                    && path.startsWith(pathToFile) && path.length() > pathToFile.length()) {
                boolean hasBody = req.getMethod().equals("GET");
                String fileName = path.substring(pathToFile.length());
                if (fileName.startsWith("src/")) {
                    if (serveSourceFile(fileName.substring("src/".length()), req, resp, hasBody)) {
                        log.debug("File " + path + " served as source file");
                        return;
                    }
                } else if (path.equals(indicatorWsPath)) {
                    if ("websocket".equalsIgnoreCase(req.getHeader("Upgrade"))) {
                        super.service(req, resp);
                        return;
                    }
                } else if (path.equals(deobfuscatorPath)) {
                    serveDeobfuscator(req, resp, hasBody);
                    return;
                } else {
                    byte[] fileContent;
                    boolean firstTime;
                    synchronized (contentLock) {
                        fileContent = content.get(fileName);
                        firstTime = this.firstTime;
                    }
                    if (fileContent != null) {
                        resp.setStatus(hasBody ? HttpServletResponse.SC_OK : HttpServletResponse.SC_NO_CONTENT);
                        if (fileName.endsWith(".js") || fileName.endsWith(".js.map")
                                || fileName.endsWith(".wasm.map")) {
                            resp.setCharacterEncoding("UTF-8");
                        }
                        allowOrigin(req, resp);
                        if (!hasBody) {
                            resp.setHeader("Access-Control-Allow-Methods", "GET");
                        } else {
                            resp.setContentType(chooseContentType(fileName));
                            noCache(resp);
                            resp.getOutputStream().write(fileContent);
                        }
                        resp.getOutputStream().flush();
                        log.debug("File " + path + " served as generated file");
                        return;
                    } else if (fileName.equals(this.fileName) && indicator && firstTime) {
                        serveBootFile(req, resp, hasBody);
                        return;
                    }
                }
            }

            if (!staticFileRoots.isEmpty() && path.startsWith(staticFilesPath)
                    && path.length() > staticFilesPath.length() + 1) {
                if (serveFile(resp, path.substring(staticFilesPath.length() + 1))) {
                    log.debug("File " + path + " served as static file");
                    return;
                }
            }
            if (resourcesRoots.isEmpty() && path.startsWith(resourcesPath)
                    && path.length() > resourcesPath.length() + 1) {
                if (serveResource(resp, path.substring(resourcesPath.length() + 1))) {
                    log.debug("File " + path + " served as resource");
                    return;
                }
            }
            if (proxyUrl != null && path.startsWith(proxyPath)) {
                if ("websocket".equalsIgnoreCase(req.getHeader("Upgrade"))) {
                    proxyWebSocket(req, resp, path);
                } else {
                    proxy(req, resp, path);
                }
                return;
            }
        }

        log.debug("File " + path + " not found");
        resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
    }

    private String chooseContentType(String name) {
        if (name.endsWith(".js")) {
            return "application/javascript";
        } else if (name.endsWith(".js.map") || name.endsWith(".wasm.map")) {
            return "application/json";
        } else if (name.endsWith(".wasm")) {
            return "application/wasm";
        } else if (name.endsWith(".teavmdbg")) {
            return "application/octet-stream";
        } else {
            return "text/plain";
        }
    }

    private void serveDeobfuscator(HttpServletRequest req, HttpServletResponse resp, boolean hasBody)
            throws IOException {
        ClassLoader loader = CodeServlet.class.getClassLoader();
        resp.setStatus(hasBody ? HttpServletResponse.SC_OK : HttpServletResponse.SC_NO_CONTENT);
        allowOrigin(req, resp);
        if (!hasBody) {
            resp.setHeader("Access-Control-Allow-Methods", "GET");
        } else {
            resp.setCharacterEncoding("UTF-8");
            resp.setContentType("application/javascript");
            noCache(resp);
            try (var input = loader.getResourceAsStream("teavm/devserver/deobfuscator.js")) {
                input.transferTo(resp.getOutputStream());
            }
        }
        resp.getOutputStream().flush();
    }

    private boolean serveFile(HttpServletResponse resp, String path) throws IOException {
        var cacheResult = tryFromCache(resp, fileCache, path);
        if (cacheResult != CacheServeResult.MISSING) {
            return cacheResult == CacheServeResult.HIT_SERVED;
        }
        var entry = new CachedEntry();
        var found = false;
        for (var root : staticFileRoots) {
            var file = new File(root, path);
            if (file.isFile()) {
                serveAndCache(resp, () -> new FileInputStream(file), entry, path);
                found = true;
                break;
            }
        }
        fileCache.put(path, entry);
        return found;
    }

    private boolean serveResource(HttpServletResponse resp, String path) throws IOException {
        var cacheResult = tryFromCache(resp, resourceCache, path);
        if (cacheResult != CacheServeResult.MISSING) {
            return cacheResult == CacheServeResult.HIT_SERVED;
        }
        prepareResources();
        var entry = new CachedEntry();
        var found = false;
        outer:
        for (var root : resourcesRoots) {
            var relPath = root.endsWith("/") ? root + path : root + "/" + path;
            for (var dir : resourceDirs) {
                var candidate = new File(dir, relPath);
                if (candidate.isFile()) {
                    serveAndCache(resp, () -> new FileInputStream(candidate), entry, path);
                    found = true;
                    break outer;
                }
            }
            for (var zip : resourceZipFiles) {
                var zipEntry = zip.getEntry(relPath);
                if (zipEntry != null) {
                    serveAndCache(resp, () -> zip.getInputStream(zipEntry), entry, path);
                    found = true;
                    break outer;
                }
            }
        }
        fileCache.put(path, entry);
        return found;
    }

    private void prepareResources() {
        if (resourceZipFiles != null) {
            return;
        }
        resourceZipFiles = new ArrayList<>();
        resourceDirs = new ArrayList<>();
        for (var classPathEntry : classPath) {
            var file = new File(classPathEntry);
            if (file.isFile()) {
                try {
                    resourceZipFiles.add(new ZipFile(file));
                } catch (IOException e) {
                    // apparently not a zip file
                }
            } else if (file.isDirectory()) {
                resourceDirs.add(file);
            }
        }
    }

    private void serveAndCache(HttpServletResponse resp, ContentProvider provider, CachedEntry entry, String name)
            throws IOException {
        try (var input = provider.open()) {
            resp.setStatus(HttpServletResponse.SC_OK);
            resp.setContentType(getServletContext().getMimeType(name));
            noCache(resp);
            var bytes = input.readNBytes(16384);
            resp.getOutputStream().write(bytes);
            if (bytes.length < 16384) {
                entry.provider = new DataContentProvider(bytes);
            } else {
                input.transferTo(resp.getOutputStream());
                entry.provider = provider;
            }
        }
    }

    private CacheServeResult tryFromCache(HttpServletResponse resp, Map<String, CachedEntry> cache, String path)
            throws IOException {
        var cachedEntry = fileCache.get(path);
        if (cachedEntry != null) {
            if (cachedEntry.provider != null) {
                resp.setStatus(HttpServletResponse.SC_OK);
                resp.setContentType(getServletContext().getMimeType(path));
                noCache(resp);
                try (var input = cachedEntry.provider.open()) {
                    input.transferTo(resp.getOutputStream());
                }
                return CacheServeResult.HIT_SERVED;
            } else {
                return CacheServeResult.HIT_NO_CONTENT;
            }
        }
        return CacheServeResult.MISSING;
    }

    enum CacheServeResult {
        HIT_SERVED,
        HIT_NO_CONTENT,
        MISSING
    }

    private void proxy(HttpServletRequest req, HttpServletResponse resp, String path) throws IOException {
        AsyncContext async = req.startAsync();

        String relPath = path.substring(proxyPath.length());
        StringBuilder sb = new StringBuilder(proxyUrl);
        if (!relPath.isEmpty() && !proxyUrl.endsWith("/")) {
            sb.append("/");
        }
        sb.append(relPath);

        if (req.getQueryString() != null) {
            sb.append("?").append(req.getQueryString());
        }
        log.debug("Trying to serve '" + relPath + "' from '" + sb + "'");

        Request proxyReq = httpClient.newRequest(sb.toString());
        proxyReq.method(req.getMethod());
        proxyReq.headers(fields -> copyRequestHeaders(req, fields::add));

        proxyReq.body(new InputStreamRequestContent(req.getInputStream()));
        HeaderSender headerSender = new HeaderSender(resp);

        proxyReq.onResponseContent((response, responseContent) -> {
            headerSender.send(response);
            try {
                WritableByteChannel channel = Channels.newChannel(resp.getOutputStream());
                while (responseContent.remaining() > 0) {
                    channel.write(responseContent);
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        proxyReq.send(result -> {
            headerSender.send(result.getResponse());
            async.complete();
        });
    }

    class HeaderSender {
        final HttpServletResponse resp;
        boolean sent;

        HeaderSender(HttpServletResponse resp) {
            this.resp = resp;
        }

        void send(Response response) {
            if (sent) {
                return;
            }

            sent = true;
            resp.setStatus(response.getStatus());

            int length = -1;
            boolean isGzip = false;
            for (HttpField field : response.getHeaders()) {
                String name = field.getName().toLowerCase();
                if (name.equals("location")) {
                    String value = field.getValue();
                    if (value.startsWith(proxyUrl)) {
                        String relLocation = value.substring(proxyUrl.length());
                        resp.addHeader(field.getName(), "http://localhost:" + port + proxyPath + relLocation);
                        continue;
                    }
                }
                if (name.equals("content-encoding")) {
                    isGzip = true;
                    continue;
                } else if (name.equals("content-length")) {
                    try {
                        length = Integer.parseInt(field.getValue());
                    } catch (NumberFormatException e) {
                        // do nothing
                    }
                    continue;
                }
                resp.addHeader(field.getName(), field.getValue());
            }

            if (length > 0 && !isGzip) {
                resp.addHeader("Content-Length", String.valueOf(length));
            }
        }
    }

    private void proxyWebSocket(HttpServletRequest req, HttpServletResponse resp, String path)
            throws IOException, ServletException {
        String relPath = path.substring(proxyPath.length());
        StringBuilder sb = new StringBuilder(proxyProtocol.equals("http") ? "ws" : "wss").append("://");
        sb.append(proxyHost);
        if (!relPath.isEmpty()) {
            sb.append("/");
        }
        sb.append(relPath);
        if (req.getQueryString() != null) {
            sb.append("?").append(req.getQueryString());
        }
        URI uri;
        try {
            uri = new URI(sb.toString());
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

        ProxyWsClient client = new ProxyWsClient();
        req.setAttribute("teavm.ws.client", client);
        ClientUpgradeRequest proxyReq = new ClientUpgradeRequest(uri);
        Map<String, List<String>> headers = new LinkedHashMap<>();
        copyRequestHeaders(req, (key, value) -> headers.computeIfAbsent(key, k -> new ArrayList<>()).add(value));
        headers.forEach(proxyReq::setHeader);

        try {
            wsClient.connect(client, proxyReq);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        super.service(req, resp);
    }

    private void copyRequestHeaders(HttpServletRequest req, HeaderConsumer proxyReq) {
        Enumeration<String> headers = req.getHeaderNames();
        while (headers.hasMoreElements()) {
            String header = headers.nextElement();
            String headerLower = header.toLowerCase();
            switch (headerLower) {
                case "host":
                    if (proxyHost != null) {
                        proxyReq.header(header, proxyHost);
                        continue;
                    }
                    break;
                case "origin":
                    if (proxyBaseUrl != null) {
                        String origin = req.getHeader(header);
                        if (origin.equals("http://localhost:" + port)) {
                            proxyReq.header(header, proxyBaseUrl);
                            continue;
                        }
                    }
                    break;
                case "referer": {
                    String referer = req.getHeader(header);
                    String localUrl = "http://localhost:" + port + "/";
                    if (referer.startsWith(localUrl)) {
                        String relReferer = referer.substring(localUrl.length());
                        proxyReq.header(header, proxyUrl + relReferer);
                        continue;
                    }
                    break;
                }
                case "connection":
                case "upgrade":
                case "user-agent":
                case "sec-websocket-key":
                case "sec-websocket-version":
                case "sec-websocket-extensions":
                case "accept-encoding":
                    continue;
            }
            Enumeration<String> values = req.getHeaders(header);
            while (values.hasMoreElements()) {
                proxyReq.header(header, values.nextElement());
            }
        }
    }

    @Override
    public void destroy() {
        super.destroy();
        if (proxyUrl != null) {
            try {
                httpClient.stop();
            } catch (Exception e) {
                log.warning("Error stopping HTTP client", e);
            }
            try {
                wsClient.stop();
            } catch (Exception e) {
                log.warning("Error stopping WebSocket client", e);
            }
        }
        stopped = true;
        synchronized (statusLock) {
            if (buildThread != null && waiting) {
                buildThread.interrupt();
            }
        }
    }

    @Override
    public void init() throws ServletException {
        super.init();
        if (compileOnStartup) {
            runCompilerThread();
        }
    }

    private void runCompilerThread() {
        var thread = new Thread(this::runTeaVM);
        thread.setName("TeaVM compiler");
        thread.start();
        buildThread = thread;
    }

    private boolean serveSourceFile(String fileName, HttpServletRequest req, HttpServletResponse resp,
            boolean hasBody) throws IOException {
        try (InputStream stream = sourceFileCache.computeIfAbsent(fileName, this::findSourceFile).get()) {
            if (stream == null) {
                return false;
            }

            resp.setStatus(hasBody ? HttpServletResponse.SC_OK : HttpServletResponse.SC_NO_CONTENT);
            resp.setCharacterEncoding("UTF-8");
            allowOrigin(req, resp);
            if (!hasBody) {
                resp.setHeader("Access-Control-Allow-Methods", "GET");
            } else {
                resp.setContentType("text/plain");
                noCache(resp);
                stream.transferTo(resp.getOutputStream());
            }
            resp.getOutputStream().flush();
            return true;
        }
    }

    private Supplier<InputStream> findSourceFile(String fileName) {
        for (String element : sourcePath) {
            File sourceFile = new File(element);
            if (sourceFile.isFile()) {
                Supplier<InputStream> result = findSourceFileInZip(sourceFile, fileName);
                if (result != null) {
                    return result;
                }
            } else if (sourceFile.isDirectory()) {
                File result = new File(sourceFile, fileName);
                if (result.exists()) {
                    return () -> {
                        try {
                            return new FileInputStream(result);
                        } catch (FileNotFoundException e) {
                            return null;
                        }
                    };
                }
            }
        }

        return EMPTY_CONTENT;
    }

    private Supplier<InputStream> findSourceFileInZip(File zipFile, String fileName) {
        try (ZipFile zip = new ZipFile(zipFile)) {
            ZipEntry entry = zip.getEntry(fileName);
            if (entry == null) {
                return null;
            }
            return () -> {
                try {
                    ZipInputStream input = new ZipInputStream(new FileInputStream(zipFile));
                    while (true) {
                        ZipEntry e = input.getNextEntry();
                        if (e == null) {
                            return null;
                        }
                        if (e.getName().equals(fileName)) {
                            return input;
                        }
                    }
                } catch (IOException e) {
                    return null;
                }
            };
        } catch (IOException e) {
            return null;
        }
    }

    private void serveBootFile(HttpServletRequest req, HttpServletResponse resp, boolean hasBody) throws IOException {
        resp.setStatus(hasBody ? HttpServletResponse.SC_OK : HttpServletResponse.SC_NO_CONTENT);
        resp.setCharacterEncoding("UTF-8");
        allowOrigin(req, resp);
        if (!hasBody) {
            resp.setHeader("Access-Control-Allow-Methods", "GET");
        } else {
            resp.setContentType("text/plain");
            noCache(resp);
            resp.getWriter().write("function main() { }\n");
            resp.getWriter().write(getIndicatorScript(true));
        }
        resp.getWriter().flush();
        log.debug("Served boot file");
    }

    private void runTeaVM() {
        try {
            initBuilder();

            var hasJob = true;
            while (!stopped) {
                if (hasJob) {
                    buildOnce();
                } else {
                    emptyBuild();
                }

                if (stopped) {
                    break;
                }

                try {
                    synchronized (statusLock) {
                        waiting = true;
                    }
                    if (fileSystemWatched) {
                        watcher.waitForChange(750);
                        log.info("Changes detected. Recompiling.");
                    } else {
                        while (true) {
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                break;
                            }
                        }
                        watcher.pollChanges();
                    }
                    synchronized (statusLock) {
                        waiting = false;
                    }
                } catch (InterruptedException e) {
                    if (stopped) {
                        break;
                    }
                    log.info("Build triggered by user");
                }

                List<String> staleClasses = getChangedClasses(watcher.grabChangedFiles());
                if (staleClasses.size() > 15) {
                    List<String> displayedStaleClasses = staleClasses.subList(0, 10);
                    log.debug("Following classes changed (" + staleClasses.size() + "): "
                            + String.join(", ", displayedStaleClasses) + " and more...");
                } else {
                    log.debug("Following classes changed (" + staleClasses.size() + "): "
                            + String.join(", ", staleClasses));
                }

                classSource.evict(staleClasses);
                hasJob = !staleClasses.isEmpty();
            }
            log.info("Build process stopped");
        } catch (Throwable e) {
            log.error("Compile server crashed", e);
        } finally {
            shutdownBuilder();
        }
    }

    private void initBuilder() throws IOException {
        watcher = new FileSystemWatcher(classPath);

        classSource = createCachedSource();
        astCache = new InMemoryMethodNodeCache(referenceCache, symbolTable, fileSymbolTable, variableSymbolTable);
        programCache = new InMemoryProgramCache(referenceCache, symbolTable, fileSymbolTable, variableSymbolTable);
    }

    private MemoryCachedClassReaderSource createCachedSource() {
        return new MemoryCachedClassReaderSource(referenceCache, symbolTable, fileSymbolTable,
                variableSymbolTable);
    }

    private void shutdownBuilder() {
        try {
            watcher.dispose();
        } catch (IOException e) {
            log.debug("Exception caught", e);
        }
        classSource = null;
        watcher = null;
        astCache = null;
        programCache = null;
        synchronized (content) {
            content.clear();
        }
        buildTarget.clear();

        log.info("Build thread complete");
    }


    private void buildOnce() {
        fireBuildStarted();
        reportProgress(0);

        ClassLoader classLoader = initClassLoader();
        var reader = ResourceProvider.ofClassPath(Stream.of(classPath).map(File::new).collect(Collectors.toList()));
        ResourceBytecodeClassHolderSource rawMapper = new ResourceBytecodeClassHolderSource(reader, referenceCache);
        var classPathMapper = new RenamingClassHolderSource(reader, referenceCache,
                rawMapper, DefaultSubstituteClassNameMapping.createWithSPI(classLoader));
        classSource.setProvider(name -> PreOptimizingClassHolderSource.optimize(classPathMapper, name));

        long startTime = System.currentTimeMillis();

        @SuppressWarnings("unchecked")
        var backend = (CodeServletBackend<TeaVMTarget>) this.backend;
        var target = backend.createTarget();
        TeaVM vm = new TeaVMBuilder(target)
                .setReferenceCache(referenceCache)
                .setClassLoader(classLoader)
                .setClassSource(classSource)
                .setResourceProvider(reader)
                .setDependencyAnalyzerFactory(FastDependencyAnalyzer::new)
                .setClassSourcePacker(this::packClasses)
                .setStrict(true)
                .setObfuscated(false)
                .build();

        var settings = new CodeServletSettings() {
            @Override
            public JSModuleType jsModuleType() {
                return jsModuleType;
            }

            @Override
            public boolean wasmSharedBuffer() {
                return wasmSharedBuffer;
            }

            @Override
            public boolean wasmModularRuntime() {
                return wasmModularRuntime;
            }

            @Override
            public String fileName() {
                return fileName;
            }
        };
        backend.setup(target, astCache, referenceCache, settings);
        vm.setOptimizationLevel(TeaVMOptimizationLevel.SIMPLE);
        vm.setCacheStatus(classSource);
        vm.addVirtualMethods(m -> true);
        vm.setProgressListener(progressListener);
        vm.setProgramCache(programCache);
        vm.installPlugins();
        for (var className : preservedClasses) {
            vm.preserveType(className);
        }
        vm.getProperties().putAll(properties);

        vm.setLastKnownClasses(lastReachedClasses);
        vm.setEntryPoint(mainClass);

        log.info("Starting build");
        progressListener.last = 0;
        progressListener.lastTime = System.currentTimeMillis();
        vm.build(buildTarget, fileName);
        if (backend.isIndicatorSupported()) {
            addIndicator();
        }
        backend.afterBuild(buildTarget, settings);

        postBuild(vm, startTime);
        reader.close();
    }

    private void emptyBuild() {
        fireBuildStarted();
        log.info("No files changed, nothing to do");
        fireBuildCompleteWithResult(null);
    }

    private ClassReaderSource packClasses(ClassReaderSource source, Collection<? extends String> classNames) {
        MemoryCachedClassReaderSource packedSource = createCachedSource();
        packedSource.setProvider(source::get);
        for (String className : classNames) {
            packedSource.populate(className);
        }
        packedSource.setProvider(null);
        return packedSource;
    }

    private void addIndicator() {
        String script = getIndicatorScript(false);
        try (Writer writer = new OutputStreamWriter(buildTarget.appendToResource(fileName), StandardCharsets.UTF_8)) {
            writer.append("\n");
            writer.append(script);
        } catch (IOException e) {
            throw new RuntimeException("IO error occurred writing debug information", e);
        }
    }

    private String getIndicatorScript(boolean boot) {
        try (var reader = new BufferedReader(new InputStreamReader(CodeServlet.class
                .getResourceAsStream("indicator.js"), StandardCharsets.UTF_8))) {
            var script = reader.lines().collect(Collectors.joining("\n"));
            script = script.substring(script.indexOf("*/") + 2);
            script = script.replace("WS_PATH", "localhost:" + port + pathToFile + fileName + ".ws");
            script = script.replace("BOOT_FLAG", Boolean.toString(boot));
            script = script.replace("RELOAD_FLAG", Boolean.toString(automaticallyReloaded));
            script = script.replace("INDICATOR_FLAG", Boolean.toString(indicator));
            script = script.replace("DEBUG_PORT", Integer.toString(debugPort));
            script = script.replace("FILE_NAME", "\"" + fileName + "\"");
            script = script.replace("PATH_TO_FILE", "\"http://localhost:" + port + pathToFile + "\"");
            script = script.replace("DEOBFUSCATE_FLAG", String.valueOf(deobfuscateStack));
            return script;
        } catch (IOException e) {
            throw new RuntimeException("IO error occurred writing debug information", e);
        }
    }

    private void postBuild(TeaVM vm, long startTime) {
        if (!vm.wasCancelled()) {
            log.info("Recompiled stale methods: " + programCache.getPendingItemsCount());
            if (vm.getProblemProvider().getSevereProblems().isEmpty()) {
                log.info("Build complete successfully");
                saveNewResult();
                lastReachedClasses = vm.getDependencyInfo().getReachableClasses().size();
                classSource.commit();
                programCache.commit();
                astCache.commit();
                reportCompilationComplete(true);
            } else {
                log.info("Build complete with errors");
                reportCompilationComplete(false);
            }
            printStats(vm, startTime);
            if (logBuildErrors) {
                TeaVMProblemRenderer.describeProblems(vm, log);
            }
            fireBuildComplete(vm);
        } else {
            log.info("Build cancelled");
            fireBuildCancelled();
        }

        astCache.discard();
        programCache.discard();
        buildTarget.clear();
        cancelRequested = false;
    }

    private void printStats(TeaVM vm, long startTime) {
        if (vm.getWrittenClasses() != null) {
            int classCount = vm.getWrittenClasses().getClassNames().size();
            int methodCount = 0;
            for (String className : vm.getWrittenClasses().getClassNames()) {
                ClassReader cls = vm.getWrittenClasses().get(className);
                methodCount += cls.getMethods().size();
            }

            log.info("Classes compiled: " + classCount);
            log.info("Methods compiled: " + methodCount);
        }

        log.info("Compilation took " + (System.currentTimeMillis() - startTime) + " ms");
    }

    private void saveNewResult() {
        synchronized (contentLock) {
            firstTime = false;
            content.clear();
            for (String name : buildTarget.getNames()) {
                content.put(name, buildTarget.getContent(name));
            }
        }
    }

    private List<String> getChangedClasses(Collection<File> changedFiles) {
        List<String> result = new ArrayList<>();
        String[] prefixes = Arrays.stream(classPath).map(s -> s.replace('\\', '/')).toArray(String[]::new);

        for (File file : changedFiles) {
            String path = file.getPath().replace('\\', '/');
            if (!path.endsWith(".class")) {
                continue;
            }

            String prefix = Arrays.stream(prefixes)
                    .filter(path::startsWith)
                    .findFirst()
                    .orElse("");
            int start = prefix.length();
            if (start < path.length() && path.charAt(start) == '/') {
                ++start;
            }

            path = path.substring(start, path.length() - ".class".length()).replace('/', '.');
            result.add(path);
        }

        return result;
    }

    private ClassLoader initClassLoader() {
        URL[] urls = new URL[classPath.length];
        try {
            for (int i = 0; i < classPath.length; i++) {
                urls[i] = new File(classPath[i]).toURI().toURL();
            }
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
        return new URLClassLoader(urls, CodeServlet.class.getClassLoader());
    }

    private void reportProgress(double progress) {
        synchronized (statusLock) {
            if (compiling && this.progress == progress) {
                return;
            }
            compiling = true;
            this.progress = progress;
        }

        ProgressHandler[] handlers;
        synchronized (progressHandlers) {
            handlers = progressHandlers.toArray(new ProgressHandler[0]);
        }

        for (ProgressHandler handler : handlers) {
            handler.progress(progress);
        }

        for (DevServerListener listener : listeners) {
            listener.compilationProgress(progress);
        }
    }

    private void reportCompilationComplete(boolean success) {
        synchronized (statusLock) {
            if (!compiling) {
                return;
            }
            compiling = false;
        }

        ProgressHandler[] handlers;
        synchronized (progressHandlers) {
            handlers = progressHandlers.toArray(new ProgressHandler[0]);
        }

        for (ProgressHandler handler : handlers) {
            handler.complete(success);
        }
    }

    private void fireBuildStarted() {
        for (DevServerListener listener : listeners) {
            listener.compilationStarted();
        }
    }

    private void fireBuildCancelled() {
        for (DevServerListener listener : listeners) {
            listener.compilationCancelled();
        }
    }

    private void fireBuildComplete(TeaVM vm) {
        fireBuildCompleteWithResult(new SimpleBuildResult(vm));
    }

    private void fireBuildCompleteWithResult(BuildResult buildResult) {
        for (var listener : listeners) {
            listener.compilationComplete(buildResult);
        }
    }

    private final ProgressListenerImpl progressListener = new ProgressListenerImpl();

    class ProgressListenerImpl implements TeaVMProgressListener {
        private int start;
        private int end;
        private int phaseLimit;
        private int last;
        private long lastTime;

        @Override
        public TeaVMProgressFeedback phaseStarted(TeaVMPhase phase, int count) {
            switch (phase) {
                case DEPENDENCY_ANALYSIS:
                    start = 0;
                    end = 500;
                    break;
                case COMPILING:
                    start = 500;
                    end = 1000;
                    break;
            }
            phaseLimit = Math.max(1, count);
            return progressReached(0);
        }

        @Override
        public TeaVMProgressFeedback progressReached(int progress) {
            if (indicator || !listeners.isEmpty()) {
                int current = start + Math.min(progress, phaseLimit) * (end - start) / phaseLimit;
                if (current != last) {
                    if (current - last > 10 || System.currentTimeMillis() - lastTime > 100) {
                        lastTime = System.currentTimeMillis();
                        last = current;
                        reportProgress(current / 10.0);
                    }
                }
            }
            return getResult();
        }

        private TeaVMProgressFeedback getResult() {
            if (cancelRequested) {
                log.info("Trying to cancel compilation due to user request");
                return TeaVMProgressFeedback.CANCEL;
            }

            if (stopped) {
                log.info("Trying to cancel compilation due to server stopping");
                return TeaVMProgressFeedback.CANCEL;
            }

            try {
                if (watcher.hasChanges()) {
                    log.info("Changes detected, cancelling build");
                    return TeaVMProgressFeedback.CANCEL;
                }
            } catch (IOException e) {
                log.info("IO error occurred", e);
                return TeaVMProgressFeedback.CANCEL;
            }

            return TeaVMProgressFeedback.CONTINUE;
        }
    }

    static String normalizePath(String path) {
        if (!path.endsWith("/")) {
            path += "/";
        }
        if (!path.startsWith("/")) {
            path = "/" + path;
        }
        return path;
    }

    static void noCache(HttpServletResponse response) {
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    }

    static void allowOrigin(HttpServletRequest req, HttpServletResponse resp) {
        String origin = req.getHeader("Origin");
        if (origin != null) {
            resp.setHeader("Access-Control-Allow-Origin", origin);
            resp.setHeader("Vary", "Origin");
        } else {
            resp.setHeader("Access-Control-Allow-Origin", "*");
        }
        resp.setHeader("Access-Control-Allow-Credentials", "true");
        resp.setHeader("Access-Control-Allow-Private-Network", "true");
    }

    private static class CachedEntry {
        ContentProvider provider;
    }

    private interface ContentProvider {
        InputStream open() throws IOException;
    }

    private static class DataContentProvider implements ContentProvider {
        private final byte[] data;

        DataContentProvider(byte[] data) {
            this.data = data;
        }

        @Override
        public InputStream open() {
            return new ByteArrayInputStream(data);
        }
    }
}
