/*
 *  Copyright 2018 Alexey Andreev.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package org.teavm.jso.dom.html;

import org.teavm.jso.JSProperty;

public abstract class HTMLScriptElement extends HTMLElement {
    @JSProperty
    public abstract String getSrc();

    @JSProperty
    public abstract void setSrc(String value);

    @JSProperty
    public abstract boolean isAsync();

    @JSProperty
    public abstract void setAsync(boolean value);

    @JSProperty
    public abstract boolean isDefer();

    @JSProperty
    public abstract void setDefer(boolean value);

    @JSProperty
    public abstract String getType();

    @JSProperty
    public abstract void setType(String value);

    @JSProperty
    public abstract String getCharset();

    @JSProperty
    public abstract void setCharset(String value);

    @JSProperty
    public abstract String getText();

    @JSProperty
    public abstract void setText(String value);
}
