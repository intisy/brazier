/*
 *  Copyright 2025 Alexey Andreev.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package org.teavm.classlib.java.nio.file;

import java.io.IOException;
import org.teavm.classlib.java.nio.file.attribute.TBasicFileAttributes;

public class TSimpleFileVisitor<T> implements TFileVisitor<T> {
    @Override
    public TFileVisitResult preVisitDirectory(T dir, TBasicFileAttributes attrs) throws IOException {
        return TFileVisitResult.CONTINUE;
    }

    @Override
    public TFileVisitResult visitFile(T file, TBasicFileAttributes attrs) throws IOException {
        return TFileVisitResult.CONTINUE;
    }

    @Override
    public TFileVisitResult visitFileFailed(T file, IOException exc) throws IOException {
        throw exc;
    }

    @Override
    public TFileVisitResult postVisitDirectory(T dir, IOException exc) throws IOException {
        if (exc != null) {
            throw exc;
        }
        return TFileVisitResult.CONTINUE;
    }
}
