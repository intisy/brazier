package org.teavm.gradle.config;

public final class ArtifactCoordinates {
    public static final String JSO = "io.github.intisy.brazier:brazier-jso:0.2.0-rc";
    public static final String JSO_APIS = "io.github.intisy.brazier:brazier-jso-apis:0.2.0-rc";
    public static final String INTEROP = "io.github.intisy.brazier:brazier-interop:0.2.0-rc";
    public static final String METAPROGRAMMING = "io.github.intisy.brazier:brazier-metaprogramming-api:0.2.0-rc";
    public static final String SPI = "io.github.intisy.brazier:brazier-extension-spi:0.2.0-rc";
    public static final String EXTENSION_PROCESSOR = "io.github.intisy.brazier:brazier-extension-annotation-processor:0.2.0-rc";
    
    public static final String CLASSLIB = "io.github.intisy.brazier:brazier-classlib:0.2.0-rc";
    public static final String JSO_IMPL = "io.github.intisy.brazier:brazier-jso-impl:0.2.0-rc";
    public static final String METAPROGRAMMING_IMPL = "io.github.intisy.brazier:brazier-metaprogramming-impl:0.2.0-rc";
    public static final String JUNIT = "io.github.intisy.brazier:brazier-junit:0.2.0-rc";
    
    public static final String TOOLS = "io.github.intisy.brazier:brazier-tooling:0.2.0-rc";
    public static final String CLI = "io.github.intisy.brazier:cli:0.2.0-rc";
    
    public static final String DEV_SERVER_RUNNER = "io.github.intisy.brazier:brazier-devserver-runner:0.2.0-rc";

    private ArtifactCoordinates() {
    }
}