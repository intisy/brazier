/*
 *  Copyright 2024 Alexey Andreev.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package org.teavm.gradle.tasks;

import org.gradle.api.DefaultTask;
import org.gradle.api.provider.Property;
import org.gradle.api.provider.SetProperty;
import org.gradle.api.tasks.Internal;
import org.gradle.api.tasks.TaskAction;

public abstract class StopJavaScriptDevServerTask extends DefaultTask {
    @Internal
    public abstract SetProperty<String> getAllProjectPaths();

    @Internal
    public abstract Property<String> getProjectPath();

    @TaskAction
    public void stopServer() {
        var codeServerManager = DevServerManager.instance();
        codeServerManager.cleanup(getAllProjectPaths().get(), getLogger());
        var pm = codeServerManager.getProjectManager(getProjectPath().get());
        pm.stop(getLogger());
    }
}
