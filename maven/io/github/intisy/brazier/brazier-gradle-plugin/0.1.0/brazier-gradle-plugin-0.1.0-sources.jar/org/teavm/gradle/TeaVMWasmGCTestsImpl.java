/*
 *  Copyright 2023 Alexey Andreev.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package org.teavm.gradle;

import org.gradle.api.model.ObjectFactory;
import org.gradle.api.provider.Property;
import org.teavm.gradle.api.TeaVMWasmGCTests;
import org.teavm.gradle.api.TeaVMWebTestRunner;

class TeaVMWasmGCTestsImpl implements TeaVMWasmGCTests {
    private Property<Boolean> enabled;
    private Property<TeaVMWebTestRunner> runner;
    private String name;

    TeaVMWasmGCTestsImpl(ObjectFactory objectFactory, String name) {
        enabled = objectFactory.property(Boolean.class);
        runner = objectFactory.property(TeaVMWebTestRunner.class);
        this.name = name;
    }

    @Override
    public Property<Boolean> getEnabled() {
        return enabled;
    }

    @Override
    public Property<TeaVMWebTestRunner> getRunner() {
        return runner;
    }

    void configure(TeaVMBaseExtensionImpl extension) {
        enabled.convention(extension.property("tests." + name + ".enabled").map(Boolean::parseBoolean).orElse(false));
        runner.convention(extension.property("tests." + name + ".runner")
                .map(s -> TeaVMWebTestRunner.valueOf(s.toUpperCase()))
                .orElse(TeaVMWebTestRunner.CHROME));
    }
}
